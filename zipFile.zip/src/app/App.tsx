import { useState, useRef } from "react";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area,
  XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid
} from "recharts";
import {
  Bell, ChevronDown, ChevronUp, Users, TrendingUp, AlertTriangle,
  Home, Wallet, Settings, LogOut, Plus, Search, Printer,
  Edit, Trash2, X, Phone, MessageSquare, FlaskConical,
  Stethoscope, Aperture, Dumbbell, DollarSign, BarChart2, Database,
  CloudUpload, UserPlus, Receipt, ChevronRight, CreditCard,
  ArrowUp, ArrowDown, Save, AlertCircle, Check, Download,
  Scissors, RefreshCw, Package, Eye, Filter, Building2,
  CheckCircle, Clock, XCircle, Archive, Menu, Banknote,
  ArrowDownCircle, ArrowUpCircle, FileText, Layers,
  ShoppingCart, Briefcase, User, Landmark, Wrench, FileEdit,
  FileDown, Ruler
} from "lucide-react";

// ─── TYPES ────────────────────────────────────────────────────────────────────

type ToastItem = { id: number; msg: string; type: "success"|"error"|"warning"|"info" };
type Route = { screen: string; dept?: string };
type DrawerTx = { id:number; type:"in"|"out"; title:string; category:string; beneficiary?:string; amount:number; balance:number; time:string; auto?:boolean };
type DrawerState = { balance:number; txs:DrawerTx[] };
type Invoice = { id:string; company:string; date:string; total:number; paid:number; remaining:number; status:"paid"|"partial"|"unpaid"; dept:string };
type DebtRow = { id:number; patient:string; pid:string; dept:string; amount:number; date:string; days:number; phone:string; smsSent?:boolean };
type Employee = { id:number; name:string; dept:string; role:string; salary:number; expenses:number; status:"pending"|"calculated"|"paid"; paidDate?:string };
type NormalRange = { param:string; unit:string; min:string; max:string; note:string };
type LabTest = { id:number; code:string; name:string; nameEn:string; cat:string; price:number; kit:string; time:string; normalRanges?:NormalRange[] };
type RadImage = { id:number; code:string; name:string; device:string; price:number; timeVal:string; timeUnit:string; instructions:string; notes:string };

// ─── CONSTANTS ─────────────────────────────────────────────────────────────────

const C = { primary:"#1B3A6B",secondary:"#0D7377",primaryLight:"#EBF3FB",secondaryLight:"#E6F4F4",bg:"#F5F5F5",card:"#FFFFFF",border:"#E0E0E0",textPrimary:"#1A1A1A",textSecondary:"#555555",textMuted:"#999999",success:"#388E3C",warning:"#FF8F00",danger:"#D32F2F",info:"#1565C0" };
const PIE_COLORS = [C.primary,C.secondary,C.success,C.warning,C.danger,C.info];
const DEPARTMENTS = [
  { id:"surgery",  name:"عيادة الجراحة العامة والطوارئ", short:"الجراحة",  Icon:Scissors     },
  { id:"lab",      name:"مختبر التحاليل الطبية",          short:"المختبر",  Icon:FlaskConical  },
  { id:"radiology",name:"الأشعة التشخيصية",               short:"الأشعة",   Icon:Aperture      },
  { id:"rehab",    name:"عيادة العلاج التأهيلي",           short:"التأهيلي", Icon:Dumbbell      },
];
const WITHDRAW_CATS = [
  {id:"salary",  label:"راتب موظف",          Icon:Briefcase,   suggest:"راتب "},
  {id:"empexp",  label:"مصروف شخصي — موظف", Icon:User,        suggest:"مصروف شخصي — "},
  {id:"invoice", label:"دفع فاتورة شركة",    Icon:Receipt,     suggest:"دفع فاتورة — "},
  {id:"purchase",label:"مشتريات مباشرة",     Icon:ShoppingCart,suggest:"مشتريات — "},
  {id:"bank",    label:"إيداع في البنك",      Icon:Landmark,    suggest:"إيداع بنكي"},
  {id:"ops",     label:"مصروف تشغيلي",       Icon:Wrench,      suggest:"مصروف تشغيلي — "},
  {id:"other",   label:"أخرى",               Icon:FileEdit,    suggest:""},
];
const DEPOSIT_TYPES = [{id:"receipt",label:"سند قبض — دفعة نقدية"},{id:"transfer",label:"تحويل من قسم آخر"},{id:"other",label:"تعديل يدوي — أخرى"}];
const LAB_CATS = ["تحاليل الدم","تحاليل البول","الهرمونات","الكيمياء الحيوية","الأمراض المعدية","تحاليل الغدة الدرقية","أخرى"];
const RAD_DEVICES = ["X-Ray","CT Scanner","MRI","Ultrasound","Mammography","Fluoroscopy","أخرى"];

// ─── MOCK DATA ─────────────────────────────────────────────────────────────────

const makeTx = (id:number,type:"in"|"out",title:string,cat:string,amount:number,bal:number,time:string,auto?:boolean,ben?:string):DrawerTx=>({id,type,title,category:cat,amount,balance:bal,time,auto,beneficiary:ben});
const initialDrawers:Record<string,DrawerState> = {
  surgery: { balance:18450, txs:[
    makeTx(1,"in","دفعة مريض — أحمد السلامة","إيراد مريض",1300,18450,"منذ 20 دقيقة",true),
    makeTx(2,"out","مصروف شخصي — هند الجابر","مصروف شخصي — موظف",80,17150,"منذ ساعة",false,"ن. هند الجابر"),
    makeTx(3,"out","دفع فاتورة — شركة الأجهزة","دفع فاتورة شركة",500,17070,"أمس"),
    makeTx(4,"in","إضافة يدوية — سند قبض","سند قبض — دفعة نقدية",200,17570,"أمس"),
    makeTx(5,"in","دفعة مريض — خالد المنصور","إيراد مريض",500,17370,"أمس",true),
  ]},
  lab:      { balance:9200,  txs:[makeTx(10,"in","دفعة مريض — فاطمة الحسن","إيراد مريض",300,9200,"منذ 30 دقيقة",true),makeTx(11,"out","راتب د. ريم الحسن — مايو","راتب موظف",6200,8900,"الأسبوع الماضي",false,"د. ريم الحسن")] },
  radiology:{ balance:12800, txs:[makeTx(20,"in","دفعة مريض — محمد كريم","إيراد مريض",750,12800,"منذ ساعة",true),makeTx(21,"out","مشتريات — أفلام أشعة","مشتريات مباشرة",320,12050,"أمس")] },
  rehab:    { balance:6500,  txs:[makeTx(30,"in","دفعة مريض — نور جاسم","إيراد مريض",400,6500,"منذ ساعتين",true)] },
};

const drawerHistory14 = [
  {date:"15/6",رصيد:12000,إيرادات:800},{date:"16/6",رصيد:14500,إيرادات:1200},{date:"17/6",رصيد:13200,إيرادات:600},
  {date:"18/6",رصيد:15800,إيرادات:1800},{date:"19/6",رصيد:14100,إيرادات:900},{date:"20/6",رصيد:16500,إيرادات:1500},
  {date:"21/6",رصيد:15200,إيرادات:700},{date:"22/6",رصيد:17000,إيرادات:1300},{date:"23/6",رصيد:16400,إيرادات:1100},
  {date:"24/6",رصيد:18000,إيرادات:1700},{date:"25/6",رصيد:17200,إيرادات:800},{date:"26/6",رصيد:19000,إيرادات:2000},
  {date:"27/6",رصيد:18200,إيرادات:900},{date:"28/6",رصيد:19500,إيرادات:1600},
];

const initialLabTests:LabTest[] = [
  {id:1,  code:"CBC",     name:"تعداد الدم الكامل",                nameEn:"Complete Blood Count",        cat:"تحاليل الدم",       price:45,  kit:"CBC Kit",     time:"فوري", normalRanges:[{param:"هيموغلوبين",unit:"g/dL",min:"12",max:"18",note:"للبالغين"},{param:"كريات الدم البيضاء",unit:"10³/μL",min:"4.5",max:"11",note:""}]},
  {id:2,  code:"UA",      name:"تحليل البول العام",                nameEn:"Urinalysis",                  cat:"تحاليل البول",      price:30,  kit:"Urine Strip", time:"فوري"},
  {id:3,  code:"FBS",     name:"سكر الدم الصيامي",                 nameEn:"Fasting Blood Sugar",         cat:"الكيمياء الحيوية",  price:25,  kit:"Glucose Kit", time:"فوري"},
  {id:4,  code:"HBA1C",   name:"سكر الدم التراكمي (HbA1c)",        nameEn:"Glycated Hemoglobin",         cat:"الكيمياء الحيوية",  price:65,  kit:"HbA1c Kit",   time:"ساعة"},
  {id:5,  code:"LFT",     name:"وظائف الكبد (LFTs)",               nameEn:"Liver Function Tests",        cat:"الكيمياء الحيوية",  price:85,  kit:"LFT Kit",     time:"ساعة"},
  {id:6,  code:"KFT",     name:"وظائف الكلى (Creatinine + BUN)",   nameEn:"Kidney Function Tests",       cat:"الكيمياء الحيوية",  price:75,  kit:"KFT Kit",     time:"ساعة"},
  {id:7,  code:"LIPID",   name:"الدهون الثلاثية والكوليسترول",    nameEn:"Lipid Profile",               cat:"الكيمياء الحيوية",  price:90,  kit:"Lipid Kit",   time:"ساعة"},
  {id:8,  code:"TSH",     name:"هرمون الغدة الدرقية (TSH)",        nameEn:"Thyroid Stimulating Hormone", cat:"الهرمونات",         price:75,  kit:"TSH Kit",     time:"يوم"},
  {id:9,  code:"T3T4",    name:"هرمون T3 و T4",                    nameEn:"Thyroid Hormones T3 T4",      cat:"الهرمونات",         price:110, kit:"Thyroid Kit", time:"يوم"},
  {id:10, code:"HBSAG",   name:"فيروس الكبد B (HBsAg)",            nameEn:"Hepatitis B Surface Antigen", cat:"الأمراض المعدية",   price:55,  kit:"HBsAg Kit",   time:"ساعة"},
  {id:11, code:"HCV",     name:"فيروس الكبد C (HCV)",              nameEn:"Hepatitis C Virus",           cat:"الأمراض المعدية",   price:65,  kit:"HCV Kit",     time:"ساعة"},
  {id:12, code:"HIV",     name:"فيروس نقص المناعة (HIV)",          nameEn:"HIV Test",                    cat:"الأمراض المعدية",   price:70,  kit:"HIV Kit",     time:"ساعة"},
  {id:13, code:"UA-ACID", name:"حمض البوليك (Uric Acid)",          nameEn:"Uric Acid",                   cat:"الكيمياء الحيوية",  price:35,  kit:"UA Kit",      time:"فوري"},
  {id:14, code:"IRON",    name:"الحديد والتشبع (Iron + TIBC)",     nameEn:"Iron Studies",                cat:"الكيمياء الحيوية",  price:80,  kit:"Iron Kit",    time:"ساعة"},
  {id:15, code:"VITD",    name:"فيتامين د (Vit D3)",               nameEn:"Vitamin D3",                  cat:"الهرمونات",         price:95,  kit:"Vit D Kit",   time:"يوم"},
  {id:16, code:"VITB12",  name:"فيتامين ب١٢ (Vit B12)",           nameEn:"Vitamin B12",                 cat:"الهرمونات",         price:85,  kit:"B12 Kit",     time:"يوم"},
  {id:17, code:"CRP",     name:"بروتين سي التفاعلي (CRP)",         nameEn:"C-Reactive Protein",          cat:"الأمراض المعدية",   price:45,  kit:"CRP Kit",     time:"فوري"},
  {id:18, code:"ESR",     name:"معدل ترسيب الدم (ESR)",            nameEn:"Erythrocyte Sedimentation",   cat:"تحاليل الدم",       price:25,  kit:"—",           time:"فوري"},
  {id:19, code:"BLOOD-GRP",name:"مجموعة الدم وعامل ريسوس",        nameEn:"Blood Group & Rh Factor",     cat:"تحاليل الدم",       price:40,  kit:"Blood Group", time:"فوري"},
  {id:20, code:"STOOL",   name:"تحليل البراز العام",               nameEn:"Stool Analysis",              cat:"تحاليل البول",      price:30,  kit:"—",           time:"ساعة"},
  {id:21, code:"BHCG",    name:"هرمون الحمل (β-HCG)",             nameEn:"Beta HCG",                    cat:"الهرمونات",         price:55,  kit:"HCG Kit",     time:"فوري"},
  {id:22, code:"PSA",     name:"البروستاتا (PSA)",                  nameEn:"Prostate-Specific Antigen",   cat:"الهرمونات",         price:80,  kit:"PSA Kit",     time:"يوم"},
  {id:23, code:"GFR",     name:"معدل ترشيح الكبيبات (GFR)",        nameEn:"Glomerular Filtration Rate",  cat:"الكيمياء الحيوية",  price:50,  kit:"KFT Kit",     time:"ساعة"},
  {id:24, code:"ELEC",    name:"الصوديوم والبوتاسيوم (Electrolytes)",nameEn:"Electrolytes Panel",        cat:"الكيمياء الحيوية",  price:70,  kit:"Electro Kit", time:"ساعة"},
  {id:25, code:"UC",      name:"ثقافة البول (Urine Culture)",       nameEn:"Urine Culture",               cat:"الأمراض المعدية",   price:90,  kit:"Culture Kit", time:"3 أيام"},
];

const initialRadImages:RadImage[] = [
  {id:1,code:"XR-CHEST",name:"صورة صدر (X-Ray)",          device:"X-Ray",      price:120,timeVal:"فوري",    timeUnit:"",instructions:"",notes:""},
  {id:2,code:"XR-HAND", name:"صورة يد (X-Ray)",           device:"X-Ray",      price:80, timeVal:"فوري",    timeUnit:"",instructions:"",notes:""},
  {id:3,code:"XR-SPINE",name:"صورة عمود فقري (X-Ray)",    device:"X-Ray",      price:150,timeVal:"فوري",    timeUnit:"",instructions:"",notes:""},
  {id:4,code:"CT-HEAD",  name:"أشعة مقطعية — رأس (CT)",  device:"CT Scanner", price:350,timeVal:"30",      timeUnit:"دقيقة",instructions:"",notes:""},
  {id:5,code:"CT-ABD",   name:"أشعة مقطعية — بطن (CT)",  device:"CT Scanner", price:380,timeVal:"30",      timeUnit:"دقيقة",instructions:"يُمنع الأكل 4 ساعات قبل الفحص",notes:""},
  {id:6,code:"MRI-KNEE", name:"رنين مغناطيسي — ركبة (MRI)",device:"MRI",      price:500,timeVal:"1",       timeUnit:"ساعة",instructions:"إزالة المعادن",notes:""},
  {id:7,code:"US-ABD",   name:"تصوير بالموجات فوق صوتية",  device:"Ultrasound", price:200,timeVal:"20",      timeUnit:"دقيقة",instructions:"",notes:""},
  {id:8,code:"MAMMO",    name:"تصوير الثدي (Mammogram)",   device:"Mammography",price:280,timeVal:"30",      timeUnit:"دقيقة",instructions:"",notes:""},
];

const mockPatients = [
  {id:"123456789",name:"أحمد محمد السلامة",  age:45,phone:"+970599123456",blood:"A+", insurance:true, dept:"surgery",  debt:1200,date:"15/06/2026"},
  {id:"987654321",name:"فاطمة علي الحسن",   age:32,phone:"+970598765432",blood:"O-", insurance:false,dept:"lab",       debt:0,   date:"20/06/2026"},
  {id:"456789123",name:"محمد يوسف كريم",    age:58,phone:"+970597456123",blood:"B+", insurance:true, dept:"radiology",debt:750, date:"22/06/2026"},
  {id:"321654987",name:"نور إبراهيم جاسم",  age:28,phone:"+970591321654",blood:"AB+",insurance:false,dept:"rehab",     debt:2100,date:"25/06/2026"},
  {id:"654321789",name:"خالد سعيد المنصور", age:51,phone:"+970598654321",blood:"A-", insurance:true, dept:"surgery",  debt:500, date:"27/06/2026"},
];
const initialDebts:DebtRow[] = [
  {id:1,patient:"أحمد محمد السلامة", pid:"123456789",dept:"الجراحة",amount:1200,date:"01/06/2026",days:28,phone:"+970599123456"},
  {id:2,patient:"نور إبراهيم جاسم",  pid:"321654987",dept:"التأهيلي",amount:2100,date:"15/05/2026",days:44,phone:"+970591321654"},
  {id:3,patient:"خالد سعيد المنصور",pid:"654321789",dept:"الجراحة",amount:500, date:"28/05/2026",days:31,phone:"+970598654321"},
  {id:4,patient:"محمد يوسف كريم",   pid:"456789123",dept:"الأشعة", amount:750, date:"10/04/2026",days:80,phone:"+970597456123"},
  {id:5,patient:"سارة حسن العمر",   pid:"789123456",dept:"المختبر",amount:450, date:"15/03/2026",days:106,phone:"+970592789123"},
];
const initialInvoices:Invoice[] = [
  {id:"INV-001",company:"شركة الدواء الوطنية",  date:"05/06/2026",total:8500, paid:8500,remaining:0,   status:"paid",   dept:"surgery"},
  {id:"INV-002",company:"مستلزمات طبية كاملة",   date:"12/06/2026",total:12300,paid:5000,remaining:7300,status:"partial",dept:"lab"},
  {id:"INV-003",company:"شركة الأجهزة الطبية",  date:"18/06/2026",total:3200, paid:0,   remaining:3200,status:"unpaid", dept:"radiology"},
  {id:"INV-004",company:"شركة الدواء الوطنية",  date:"25/06/2026",total:6800, paid:6800,remaining:0,   status:"paid",   dept:"surgery"},
];
const initialEmployees:Employee[] = [
  {id:1,name:"د. أحمد الزيدان", dept:"surgery",  role:"طبيب جراح",       salary:8500,expenses:350,status:"calculated"},
  {id:2,name:"د. ريم الحسن",   dept:"lab",       role:"طبيب مختبر",      salary:6200,expenses:120,status:"paid",paidDate:"25/06/2026"},
  {id:3,name:"م. خالد النمر",  dept:"radiology", role:"فني أشعة",        salary:5800,expenses:200,status:"pending"},
  {id:4,name:"د. سلمى فارس",  dept:"rehab",     role:"معالج فيزيائي",    salary:7000,expenses:450,status:"paid",paidDate:"25/06/2026"},
  {id:5,name:"ن. هند الجابر", dept:"surgery",   role:"ممرضة",            salary:4500,expenses:80, status:"pending"},
];
const initialInventory = [
  {id:1,name:"CBC Kit",       tests:["تعداد الدم الكامل"],          qty:45,threshold:20,status:"ok"      as const},
  {id:2,name:"Chemistry Kit", tests:["وظائف الكبد","وظائف الكلى"],  qty:12,threshold:15,status:"low"     as const},
  {id:3,name:"Hormone Kit",   tests:["هرمون الغدة الدرقية"],       qty:3, threshold:10,status:"critical" as const},
  {id:4,name:"Diabetes Kit",  tests:["سكر الدم التراكمي"],         qty:28,threshold:10,status:"ok"      as const},
  {id:5,name:"Urine Kit",     tests:["تحليل البول العام"],          qty:0, threshold:20,status:"empty"   as const},
];
const labSessions = [
  {id:1,patient:"أحمد محمد السلامة",tests:["تعداد الدم الكامل","وظائف الكبد"],time:"09:15",status:"pending" as const},
  {id:2,patient:"فاطمة علي الحسن",  tests:["سكر الدم التراكمي"],             time:"10:30",status:"done"    as const},
  {id:3,patient:"محمد يوسف كريم",   tests:["وظائف الكلى","هرمون الغدة"],     time:"11:00",status:"pending" as const},
  {id:4,patient:"نور إبراهيم جاسم", tests:["تحليل البول العام"],              time:"11:45",status:"done"    as const},
];
const revenueByDept  = [{name:"الجراحة",إيرادات:45200},{name:"المختبر",إيرادات:28500},{name:"الأشعة",إيرادات:33800},{name:"التأهيلي",إيرادات:19600}];
const monthlyTrend   = [{month:"يناير",إيرادات:42000,سحوبات:28000},{month:"فبراير",إيرادات:38000,سحوبات:25000},{month:"مارس",إيرادات:51000,سحوبات:31000},{month:"أبريل",إيرادات:47000,سحوبات:29000},{month:"مايو",إيرادات:55000,سحوبات:33000},{month:"يونيو",إيرادات:61000,سحوبات:35000}];
const drawersBars    = [{name:"الجراحة",رصيد:18450},{name:"المختبر",رصيد:9200},{name:"الأشعة",رصيد:12800},{name:"التأهيلي",رصيد:6500}];
const withdrawCats   = [{name:"رواتب",value:32000},{name:"فواتير",value:18500},{name:"مصروفات",value:8200},{name:"إيداعات بنكية",value:12000},{name:"أخرى",value:4100}];
const patientsPie    = [{name:"الجراحة",value:89},{name:"المختبر",value:156},{name:"الأشعة",value:67},{name:"التأهيلي",value:112}];

// ─── UTILS ─────────────────────────────────────────────────────────────────────

const fmt = (n:number) => `₪ ${n.toLocaleString("en-US")}`;

// ─── PRIMITIVES ────────────────────────────────────────────────────────────────

function Badge({color,children}:{color:"success"|"warning"|"danger"|"info"|"neutral";children:React.ReactNode}){
  const s={success:"bg-[#E8F5E9] text-[#388E3C]",warning:"bg-[#FFF8E1] text-[#FF8F00]",danger:"bg-[#FFEBEE] text-[#D32F2F]",info:"bg-[#E3F2FD] text-[#1565C0]",neutral:"bg-[#F5F5F5] text-[#555555]"};
  return <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold ${s[color]}`}>{children}</span>;
}

function KPICard({title,value,sub,Icon,color="primary",trend}:{title:string;value:string;sub?:string;Icon:React.ComponentType<{size?:number}>;color?:"primary"|"secondary"|"danger"|"success"|"warning";trend?:{val:string;up:boolean}}){
  const ic={primary:"bg-[#EBF3FB] text-[#1B3A6B]",secondary:"bg-[#E6F4F4] text-[#0D7377]",danger:"bg-[#FFEBEE] text-[#D32F2F]",success:"bg-[#E8F5E9] text-[#388E3C]",warning:"bg-[#FFF8E1] text-[#FF8F00]"};
  return(
    <div className="bg-white rounded-xl p-5 shadow-sm hover:shadow-md transition-all hover:scale-[1.01]" style={{border:"1px solid #E0E0E0"}}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-xs text-[#555555] mb-1">{title}</p>
          <p className="text-2xl font-bold text-[#1B3A6B]">{value}</p>
          {sub&&<p className="text-xs text-[#999] mt-1">{sub}</p>}
          {trend&&<div className={`flex items-center gap-1 mt-2 text-xs font-medium ${trend.up?"text-[#388E3C]":"text-[#D32F2F]"}`}>{trend.up?<ArrowUp size={11}/>:<ArrowDown size={11}/>}<span>{trend.val} الشهر الماضي</span></div>}
        </div>
        <div className={`w-12 h-12 rounded-full flex-shrink-0 flex items-center justify-center ${ic[color]}`}><Icon size={22}/></div>
      </div>
    </div>
  );
}

function Modal({open,onClose,title,children,footer,wide}:{open:boolean;onClose:()=>void;title:string;children:React.ReactNode;footer?:React.ReactNode;wide?:boolean}){
  if(!open)return null;
  return(
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{backgroundColor:"rgba(0,0,0,0.5)",backdropFilter:"blur(2px)"}}>
      <div className={`bg-white rounded-2xl shadow-2xl flex flex-col w-full ${wide?"max-w-2xl":"max-w-lg"} max-h-[90vh]`} dir="rtl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E0E0E0]">
          <h2 className="text-base font-bold text-[#1B3A6B]">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-[#F5F5F5] flex items-center justify-center text-[#555] transition-colors"><X size={18}/></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6">{children}</div>
        {footer&&<div className="px-6 py-4 border-t border-[#E0E0E0] flex gap-3 justify-start">{footer}</div>}
      </div>
    </div>
  );
}

function ConfirmModal({open,onClose,onConfirm,title,message,danger}:{open:boolean;onClose:()=>void;onConfirm:()=>void;title:string;message:string;danger?:boolean}){
  return(
    <Modal open={open} onClose={onClose} title={title}
      footer={<><Btn variant={danger?"danger":"primary"} onClick={onConfirm}><Check size={16}/>تأكيد</Btn><Btn variant="outline" onClick={onClose}>إلغاء</Btn></>}>
      <p className="text-sm text-[#555] leading-relaxed">{message}</p>
    </Modal>
  );
}

function Card({title,action,children,className=""}:{title?:string;action?:React.ReactNode;children:React.ReactNode;className?:string}){
  return(
    <div className={`bg-white rounded-xl shadow-sm ${className}`} style={{border:"1px solid #E0E0E0"}}>
      {title&&<div className="flex items-center justify-between px-5 py-4 border-b border-[#F0F0F0]"><h3 className="text-sm font-semibold text-[#1B3A6B]">{title}</h3>{action}</div>}
      <div className="p-5">{children}</div>
    </div>
  );
}

function InputField({label,required,type="text",placeholder,value,onChange,children}:{label:string;required?:boolean;type?:string;placeholder?:string;value?:string;onChange?:(v:string)=>void;children?:React.ReactNode}){
  return(
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-semibold text-[#555555]">{label}{required&&<span className="text-[#D32F2F] mr-1">*</span>}</label>
      {children||<input type={type} placeholder={placeholder} value={value} onChange={e=>onChange?.(e.target.value)} className="h-10 px-3 rounded-lg text-sm text-[#1A1A1A] outline-none transition-all" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}} onFocus={e=>{e.target.style.borderColor="#0D7377";e.target.style.boxShadow="0 0 0 3px rgba(13,115,119,0.12)"}} onBlur={e=>{e.target.style.borderColor="#CCCCCC";e.target.style.boxShadow="none"}}/>}
    </div>
  );
}

function Btn({variant="primary",onClick,children,small,full,disabled,loading}:{variant?:"primary"|"secondary"|"outline"|"danger"|"success"|"ghost";onClick?:()=>void;children:React.ReactNode;small?:boolean;full?:boolean;disabled?:boolean;loading?:boolean}){
  const s={primary:"bg-[#1B3A6B] text-white hover:bg-[#142d55]",secondary:"bg-[#0D7377] text-white hover:bg-[#0a5c60]",outline:"bg-transparent text-[#1B3A6B] border-[#1B3A6B] hover:bg-[#EBF3FB]",danger:"bg-[#D32F2F] text-white hover:bg-[#b71c1c]",success:"bg-[#388E3C] text-white hover:bg-[#2e7d32]",ghost:"bg-transparent text-[#555] hover:bg-[#F5F5F5]"};
  return(
    <button onClick={onClick} disabled={disabled||loading}
      className={`inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-all duration-150 ${small?"px-3 py-1.5 text-xs":"px-4 py-2 text-sm"} ${s[variant]} ${variant==="outline"?"border":""} ${full?"w-full":""} ${disabled||loading?"opacity-50 cursor-not-allowed":""}`}>
      {loading?<><RefreshCw size={small?12:14} className="animate-spin"/>جارٍ...</>:children}
    </button>
  );
}

// ─── TOAST ─────────────────────────────────────────────────────────────────────

function ToastContainer({toasts}:{toasts:ToastItem[]}){
  if(!toasts.length)return null;
  const s={success:"bg-[#388E3C]",error:"bg-[#D32F2F]",warning:"bg-[#FF8F00]",info:"bg-[#1565C0]"};
  const i={success:<CheckCircle size={16}/>,error:<XCircle size={16}/>,warning:<AlertTriangle size={16}/>,info:<AlertCircle size={16}/>};
  return(
    <div className="fixed bottom-6 left-6 z-[100] flex flex-col gap-2" dir="rtl">
      {toasts.map(t=><div key={t.id} className={`flex items-center gap-3 px-4 py-3 rounded-xl text-white text-sm font-medium shadow-lg ${s[t.type]}`} style={{animation:"slideUp 0.3s ease"}}>{i[t.type]}{t.msg}</div>)}
    </div>
  );
}

// ─── WITHDRAW / DEPOSIT MODALS ─────────────────────────────────────────────────

function WithdrawModal({open,onClose,dept,balance,onConfirm}:{open:boolean;onClose:()=>void;dept:string;balance:number;onConfirm:(amount:number,title:string,cat:string,ben?:string)=>void}){
  const [amount,setAmount]=useState(""); const [cat,setCat]=useState(""); const [title,setTitle]=useState(""); const [ben,setBen]=useState(""); const [loading,setLoading]=useState(false);
  const deptInfo=DEPARTMENTS.find(d=>d.id===dept); const num=parseFloat(amount)||0; const newBal=balance-num; const over=num>balance; const selCat=WITHDRAW_CATS.find(c=>c.id===cat);
  const handleCat=(c:string)=>{setCat(c);const f=WITHDRAW_CATS.find(x=>x.id===c);if(f)setTitle(f.suggest)};
  const doConfirm=()=>{if(!num||!cat||!title.trim())return;setLoading(true);setTimeout(()=>{onConfirm(num,title,selCat?.label||cat,ben||undefined);setLoading(false);setAmount("");setCat("");setTitle("");setBen("");onClose();},600)};
  return(
    <Modal open={open} onClose={onClose} title={`تسجيل سحب من جرار ${deptInfo?.short||""}`}
      footer={<><Btn variant="danger" loading={loading} onClick={doConfirm} disabled={!num||!cat||!title.trim()||over}><ArrowDownCircle size={16}/>تأكيد السحب</Btn><Btn variant="outline" onClick={onClose}>إلغاء</Btn></>}>
      <div className="space-y-4">
        <div className="p-3 rounded-xl bg-[#EBF3FB] text-sm">الرصيد الحالي: <strong className="text-[#1B3A6B] text-base">{fmt(balance)}</strong></div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-[#555]">المبلغ (₪) <span className="text-[#D32F2F]">*</span></label>
          <input type="number" placeholder="0" value={amount} onChange={e=>setAmount(e.target.value)} className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:`1px solid ${over?"#D32F2F":"#CCCCCC"}`,backgroundColor:"#FAFAFA"}}/>
          {num>0&&<p className={`text-xs font-semibold ${over?"text-[#D32F2F]":"text-[#0D7377]"}`}>{over?"⚠️ يتجاوز رصيد الجرار":`الرصيد بعد السحب: ${fmt(newBal)}`}</p>}
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-[#555]">التصنيف <span className="text-[#D32F2F]">*</span></label>
          <select value={cat} onChange={e=>handleCat(e.target.value)} className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}>
            <option value="">اختر التصنيف</option>{WITHDRAW_CATS.map(c=><option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
          {cat==="bank"&&<p className="text-xs text-[#1565C0] bg-[#E3F2FD] px-2 py-1 rounded">حركة داخلية — لن تُحتسب كمصروف</p>}
        </div>
        <InputField label="العنوان / الوصف" required placeholder="وصف عملية السحب..." value={title} onChange={setTitle}/>
        {(cat==="salary"||cat==="empexp")&&<div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">المستفيد</label><select value={ben} onChange={e=>setBen(e.target.value)} className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}><option value="">اختر الموظف</option>{initialEmployees.filter(e=>e.dept===dept).map(e=><option key={e.id}>{e.name}</option>)}</select></div>}
        {cat==="invoice"&&<div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">الشركة</label><select value={ben} onChange={e=>setBen(e.target.value)} className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}><option value="">اختر الشركة</option>{["شركة الدواء الوطنية","مستلزمات طبية كاملة","شركة الأجهزة الطبية"].map(c=><option key={c}>{c}</option>)}</select></div>}
      </div>
    </Modal>
  );
}

function DepositModal({open,onClose,dept,balance,onConfirm}:{open:boolean;onClose:()=>void;dept:string;balance:number;onConfirm:(amount:number,title:string,type:string)=>void}){
  const [amount,setAmount]=useState(""); const [type,setType]=useState(""); const [title,setTitle]=useState(""); const [loading,setLoading]=useState(false);
  const deptInfo=DEPARTMENTS.find(d=>d.id===dept); const num=parseFloat(amount)||0;
  const doConfirm=()=>{if(!num||!type||!title.trim())return;setLoading(true);setTimeout(()=>{onConfirm(num,title,DEPOSIT_TYPES.find(t=>t.id===type)?.label||type);setLoading(false);setAmount("");setType("");setTitle("");onClose();},600)};
  return(
    <Modal open={open} onClose={onClose} title={`تسجيل إضافة لجرار ${deptInfo?.short||""}`}
      footer={<><Btn variant="success" loading={loading} onClick={doConfirm} disabled={!num||!type||!title.trim()}><ArrowUpCircle size={16}/>تأكيد الإضافة</Btn><Btn variant="outline" onClick={onClose}>إلغاء</Btn></>}>
      <div className="space-y-4">
        <div className="p-3 rounded-xl bg-[#E6F4F4] text-sm">الرصيد الحالي: <strong className="text-[#0D7377] text-base">{fmt(balance)}</strong></div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-[#555]">المبلغ (₪) <span className="text-[#D32F2F]">*</span></label>
          <input type="number" placeholder="0" value={amount} onChange={e=>setAmount(e.target.value)} className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}/>
          {num>0&&<p className="text-xs text-[#388E3C] font-semibold">الرصيد بعد الإضافة: {fmt(balance+num)}</p>}
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold text-[#555]">نوع الإضافة <span className="text-[#D32F2F]">*</span></label>
          <select value={type} onChange={e=>setType(e.target.value)} className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}>
            <option value="">اختر نوع الإضافة</option>{DEPOSIT_TYPES.map(t=><option key={t.id} value={t.id}>{t.label}</option>)}
          </select>
        </div>
        <InputField label="العنوان / وصف السند" required placeholder="مثال: دفعة نقدية من مريض سابق" value={title} onChange={setTitle}/>
      </div>
    </Modal>
  );
}

// ─── TOPBAR & ALERT ────────────────────────────────────────────────────────────

function TopBar({pageTitle,sidebarCollapsed,onToggle,notifCount}:{pageTitle:string;sidebarCollapsed:boolean;onToggle:()=>void;notifCount:number}){
  const [notifOpen,setNotifOpen]=useState(false);
  const today=new Date().toLocaleDateString("ar-SA",{day:"2-digit",month:"long",year:"numeric"});
  return(
    <div className="fixed top-0 right-0 left-0 z-30 flex items-center justify-between px-5 bg-white" style={{height:60,marginRight:sidebarCollapsed?64:260,borderBottom:"1px solid #E0E0E0",boxShadow:"0 1px 3px rgba(0,0,0,0.06)",transition:"margin-right 0.25s ease"}}>
      <div className="flex items-center gap-3">
        <button onClick={onToggle} className="w-9 h-9 rounded-lg hover:bg-[#F5F5F5] flex items-center justify-center text-[#555] transition-colors"><Menu size={20}/></button>
        <h1 className="text-base font-bold text-[#1B3A6B]">{pageTitle}</h1>
      </div>
      <div className="flex items-center gap-4">
        <span className="text-xs text-[#999] hidden sm:block">{today}</span>
        <div className="relative">
          <button onClick={()=>setNotifOpen(!notifOpen)} className="w-9 h-9 rounded-lg hover:bg-[#F5F5F5] flex items-center justify-center text-[#555] relative transition-colors">
            <Bell size={20}/>{notifCount>0&&<span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#D32F2F] text-white text-[9px] flex items-center justify-center font-bold">{notifCount}</span>}
          </button>
          {notifOpen&&(
            <div className="absolute left-0 top-full mt-2 w-80 bg-white rounded-xl shadow-xl z-50" style={{border:"1px solid #E0E0E0"}} dir="rtl">
              <div className="flex items-center justify-between p-3 border-b border-[#F0F0F0]"><span className="text-xs font-bold text-[#1B3A6B]">الإشعارات</span><button className="text-xs text-[#0D7377] hover:underline">تحديد الكل كمقروء</button></div>
              {[{text:"مخزون Hormone Kit وصل للحد الأدنى: 3 قطع",time:"منذ ساعة"},{text:"مريض جديد: أحمد محمد السلامة — الجراحة",time:"منذ ساعتين"},{text:"فاتورة INV-003 غير مسددة منذ 11 يوم",time:"منذ يوم"}].map((n,i)=>(
                <div key={i} className="px-4 py-3 hover:bg-[#F9F9F9] border-b border-[#F5F5F5] last:border-0 transition-colors">
                  <p className="text-xs text-[#1A1A1A] leading-snug">{n.text}</p><p className="text-[10px] text-[#999] mt-0.5">{n.time}</p>
                </div>
              ))}
              <div className="p-2 text-center"><button className="text-xs text-[#0D7377] font-medium hover:underline">عرض الكل</button></div>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-[#1B3A6B] text-white flex items-center justify-center text-xs font-bold">م</div>
          <span className="text-sm font-medium text-[#1A1A1A] hidden sm:block">المدير</span>
        </div>
      </div>
    </div>
  );
}

function AlertBanner({totalDebt,onClose}:{totalDebt:number;onClose:()=>void}){
  return(
    <div className="flex items-center justify-between px-5 py-2.5 text-sm font-medium" style={{backgroundColor:"#FFF3E0",borderBottom:"1px solid #FFCC02",color:"#E65100"}}>
      <div className="flex items-center gap-2"><AlertTriangle size={16}/><span>تنبيه: يوجد ديون بقيمة <strong>{fmt(totalDebt)}</strong> على المرضى</span><button className="underline text-xs mr-2 opacity-75 hover:opacity-100">عرض التفاصيل</button></div>
      <button onClick={onClose} className="hover:opacity-70"><X size={16}/></button>
    </div>
  );
}

// ─── SIDEBAR ───────────────────────────────────────────────────────────────────

const NAV_ITEMS = [
  {id:"dashboard",label:"الرئيسية",Icon:Home,children:[]},
  ...DEPARTMENTS.map(d=>({
    id:d.id,label:d.name,Icon:d.Icon,
    children:[
      {id:`${d.id}-op`,  label:"فتح ملف مريض",  screen:"open-patient"},
      {id:`${d.id}-drw`, label:"الجرار وحركاته", screen:"drawer-movements"},
      ...(d.id==="lab"       ?[{id:"lab-cat", label:"دليل الفحوصات والأسعار",screen:"test-catalog"}]:[]),
      ...(d.id==="radiology" ?[{id:"rad-cat", label:"دليل الصور والأسعار",   screen:"image-catalog"}]:[]),
    ],
  })),
  {id:"financial",label:"النظام المالي",Icon:Wallet,children:[
    {id:"fin-summary",  label:"الملخص المالي",        screen:"fin-summary"},
    {id:"fin-drawer",   label:"الجرار — كل الأقسام",  screen:"fin-drawer"},
    {id:"fin-revenue",  label:"الإيرادات",             screen:"fin-revenue"},
    {id:"fin-payroll",  label:"الرواتب",               screen:"fin-payroll"},
    {id:"fin-debts",    label:"الديون",                screen:"fin-debts"},
    {id:"fin-statements",label:"الكشوفات والتقارير",   screen:"fin-statements"},
  ]},
  {id:"settings",label:"إعدادات النظام",Icon:Settings,children:[
    {id:"s-inv",    label:"المخزون والكيتات",   screen:"inventory"},
    {id:"s-backup", label:"النسخ الاحتياطي",   screen:"backup"},
    {id:"s-print",  label:"إعدادات الطباعة",   screen:"print-settings"},
    {id:"s-gen",    label:"الإعدادات العامة",   screen:"general-settings"},
  ]},
];

function Sidebar({collapsed,activeRoute,onNavigate}:{collapsed:boolean;activeRoute:Route;onNavigate:(r:Route)=>void}){
  const [expanded,setExpanded]=useState<Record<string,boolean>>({});
  const toggle=(id:string)=>setExpanded(p=>({...p,[id]:!p[id]}));
  return(
    <div className="fixed right-0 top-0 bottom-0 z-40 flex flex-col overflow-hidden" style={{width:collapsed?64:260,backgroundColor:C.primary,transition:"width 0.25s ease",boxShadow:"-2px 0 8px rgba(0,0,0,0.15)"}}>
      <div className="flex items-center gap-3 px-4 py-4 border-b" style={{borderColor:"rgba(255,255,255,0.15)",minHeight:60}}>
        <div className="w-8 h-8 rounded-lg bg-[#0D7377] flex items-center justify-center flex-shrink-0"><Stethoscope size={18} className="text-white"/></div>
        {!collapsed&&<div className="overflow-hidden"><p className="text-white text-sm font-bold truncate">المركز الصحي</p><p className="text-white/60 text-[10px] truncate">إدارة شاملة</p></div>}
      </div>
      <nav className="flex-1 overflow-y-auto py-2">
        {NAV_ITEMS.map(item=>{
          const isExp=expanded[item.id]; const hasKids=item.children.length>0;
          const isDash=item.id==="dashboard"&&activeRoute.screen==="dashboard";
          return(
            <div key={item.id}>
              <button onClick={()=>hasKids?toggle(item.id):onNavigate({screen:"dashboard"})} title={collapsed?item.label:undefined}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-white/80 hover:text-white hover:bg-white/10 transition-all"
                style={{backgroundColor:isDash?"rgba(13,115,119,0.5)":undefined,borderLeft:isDash?"3px solid #0D7377":"3px solid transparent"}}>
                <item.Icon size={20} className="flex-shrink-0"/>
                {!collapsed&&<><span className="flex-1 text-right text-sm font-medium truncate">{item.label}</span>{hasKids&&(isExp?<ChevronUp size={14}/>:<ChevronDown size={14}/>)}</>}
              </button>
              {!collapsed&&hasKids&&isExp&&(
                <div className="bg-black/20">
                  {item.children.map((child:any)=>{
                    const deptId=DEPARTMENTS.find(d=>d.id===item.id)?.id;
                    const active=activeRoute.screen===child.screen&&(!deptId||activeRoute.dept===deptId);
                    return(
                      <button key={child.id} onClick={()=>onNavigate({screen:child.screen,dept:deptId})}
                        className="w-full flex items-center gap-2 px-5 py-2 text-white/70 hover:text-white hover:bg-white/10 transition-all"
                        style={{backgroundColor:active?"rgba(13,115,119,0.5)":undefined,borderLeft:active?"3px solid #0D7377":"3px solid transparent"}}>
                        <ChevronRight size={12} className="flex-shrink-0"/><span className="text-xs text-right truncate">{child.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>
      {!collapsed&&<div className="p-4 border-t" style={{borderColor:"rgba(255,255,255,0.15)"}}><button className="w-full flex items-center gap-3 text-white/60 hover:text-white transition-colors text-sm"><LogOut size={18}/><span>تسجيل الخروج</span></button></div>}
    </div>
  );
}

// ─── TABLE HELPERS ─────────────────────────────────────────────────────────────

function THead({cols}:{cols:string[]}){return<thead><tr style={{backgroundColor:C.primary,color:"white"}}>{cols.map(c=><th key={c} className="px-3 py-2.5 text-right text-xs font-semibold">{c}</th>)}</tr></thead>;}
function TRow({i,children}:{i:number;children:React.ReactNode}){return<tr style={{backgroundColor:i%2===0?"#FFF":"#F9FBFD"}} className="hover:bg-[#EBF3FB] transition-colors">{children}</tr>;}
function TD({children,className=""}:{children?:React.ReactNode;className?:string}){return<td className={`px-3 py-3 text-sm ${className}`}>{children}</td>;}
function EmptyState({msg="لا توجد بيانات بعد"}:{msg?:string}){return<div className="flex flex-col items-center justify-center py-12 text-center"><Archive size={36} className="text-[#CCC] mb-2"/><p className="text-sm text-[#999]">{msg}</p></div>;}

// ─── SESSION DETAIL DRAWER ─────────────────────────────────────────────────────

function SessionDrawer({open,onClose,session}:{open:boolean;onClose:()=>void;session:any}){
  return(
    <>
      {open&&<div className="fixed inset-0 z-40 bg-black/40" onClick={onClose}/>}
      <div className="fixed top-0 left-0 bottom-0 z-50 w-[400px] bg-white shadow-2xl flex flex-col transition-all duration-300" style={{transform:open?"translateX(0)":"translateX(-100%)"}} dir="rtl">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E0E0E0]" style={{backgroundColor:C.primary}}>
          <h2 className="text-base font-bold text-white">تفاصيل الجلسة</h2>
          <button onClick={onClose} className="text-white/80 hover:text-white"><X size={20}/></button>
        </div>
        {session&&(
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            <div className="p-3 rounded-xl bg-[#EBF3FB]">
              {[["التاريخ",session.date],["القسم",session.dept],["التشخيص",session.diagnosis]].map(([k,v])=>(
                <div key={k} className="flex justify-between text-sm py-1"><span className="text-[#999]">{k}</span><span className="font-medium">{v}</span></div>
              ))}
            </div>
            <div><p className="text-xs font-bold text-[#555] mb-2">الأدوية</p><div className="flex gap-1.5 flex-wrap">{["أموكسيسيلين 500mg","بروفين 400mg"].map(d=><Badge key={d} color="info">{d}</Badge>)}</div></div>
            <div className="p-3 rounded-xl border border-[#E0E0E0]">
              <p className="text-xs font-bold text-[#555] mb-2">التفاصيل المالية</p>
              {[["سعر الخدمة",fmt(session.price)],["المدفوع",fmt(session.paid)],["الدين",session.debt>0?fmt(session.debt):"—"]].map(([k,v])=>(
                <div key={k} className="flex justify-between text-sm py-1 border-b border-[#F5F5F5] last:border-0"><span className="text-[#999]">{k}</span><span className={`font-semibold ${k==="الدين"&&session.debt>0?"text-[#D32F2F]":"text-[#1A1A1A]"}`}>{v}</span></div>
              ))}
            </div>
          </div>
        )}
        <div className="p-4 border-t border-[#E0E0E0]"><Btn variant="outline" full onClick={onClose}>إغلاق</Btn></div>
      </div>
    </>
  );
}

// ─── DASHBOARD ─────────────────────────────────────────────────────────────────

function DashboardScreen({drawers,onNavigate}:{drawers:Record<string,DrawerState>;onNavigate:(r:Route)=>void}){
  const totalBalance=Object.values(drawers).reduce((s,d)=>s+d.balance,0);
  return(
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 bg-white rounded-lg px-3 py-2 shadow-sm" style={{border:"1px solid #E0E0E0"}}><Filter size={15} className="text-[#555]"/><select className="text-sm bg-transparent outline-none"><option>هذا الشهر</option><option>الشهر الماضي</option><option>هذه السنة</option></select></div>
        <button className="flex items-center gap-2 text-xs text-[#555] hover:text-[#1B3A6B] transition-colors"><RefreshCw size={14}/><span>آخر تحديث: منذ دقيقتين</span></button>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <KPICard title="الرصيد الكلي لجميع الجرارات" value={fmt(totalBalance)} Icon={Banknote} color="secondary" trend={{val:"+12%",up:true}}/>
        <KPICard title="إجمالي الإيرادات (من المرضى)" value={fmt(127100)} Icon={TrendingUp} color="success"/>
        <KPICard title="إجمالي سحوبات الجرار" value={fmt(46100)} Icon={ArrowDownCircle} color="primary"/>
        <KPICard title="إجمالي المرضى" value="424" Icon={Users} color="secondary" trend={{val:"+8%",up:true}}/>
        <KPICard title="ديون المرضى غير المسددة" value={fmt(19200)} Icon={AlertTriangle} color="danger"/>
        <KPICard title="صافي الربح" value={fmt(81000)} Icon={DollarSign} color="success"/>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {DEPARTMENTS.map(d=>(
          <div key={d.id} className="rounded-xl p-4 text-white cursor-pointer hover:opacity-90 transition-opacity" style={{background:`linear-gradient(135deg,${C.primary},#0D4480)`}} onClick={()=>onNavigate({screen:"drawer-movements",dept:d.id})}>
            <div className="flex items-center justify-between mb-2"><p className="text-white/70 text-xs">جرار {d.short}</p><d.Icon size={16} className="text-white/50"/></div>
            <p className="text-xl font-bold">{fmt(drawers[d.id]?.balance||0)}</p>
            <p className="text-xs text-white/50 mt-1">عرض التفاصيل →</p>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Card title="الإيرادات حسب القسم">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={revenueByDept} margin={{top:5,right:0,left:-10,bottom:5}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0"/>
              <XAxis dataKey="name" tick={{fontSize:11,fill:"#555"}}/><YAxis tick={{fontSize:10,fill:"#555"}}/>
              <Tooltip formatter={(v:number)=>fmt(v)}/>
              <Bar dataKey="إيرادات" name="d-rev" fill={C.secondary} radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card title="توزيع المرضى حسب القسم">
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={patientsPie} cx="50%" cy="50%" outerRadius={75} dataKey="value" nameKey="name" label={({name,value})=>`${name}: ${value}`} labelLine={false}>
                {patientsPie.map((_,i)=><Cell key={`dp-${i}`} fill={PIE_COLORS[i%PIE_COLORS.length]}/>)}
              </Pie>
              <Tooltip/><Legend wrapperStyle={{fontSize:11}}/>
            </PieChart>
          </ResponsiveContainer>
        </Card>
        <Card title="مقارنة شهرية — إيرادات مقابل سحوبات" className="col-span-2">
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={monthlyTrend} margin={{top:5,right:0,left:-10,bottom:5}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0"/>
              <XAxis dataKey="month" tick={{fontSize:10,fill:"#555"}}/><YAxis tick={{fontSize:10,fill:"#555"}}/>
              <Tooltip formatter={(v:number)=>fmt(v)}/><Legend wrapperStyle={{fontSize:11}}/>
              <Line type="monotone" dataKey="إيرادات" name="d-line-rev" stroke={C.secondary} strokeWidth={2.5} dot={{r:4}}/>
              <Line type="monotone" dataKey="سحوبات" name="d-line-wd" stroke={C.danger} strokeWidth={2} dot={{r:3}} strokeDasharray="4 3"/>
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
}

// ─── OPEN PATIENT ──────────────────────────────────────────────────────────────

function OpenPatientScreen({dept,onNavigate,toast}:{dept:string;onNavigate:(r:Route)=>void;toast:(m:string,t?:any)=>void}){
  const [mode,setMode]=useState<"choice"|"search-new"|"search-reg">("choice");
  const [idCheck,setIdCheck]=useState(""); const [found,setFound]=useState<any>(null); const [notFound,setNotFound]=useState(false); const [regSearch,setRegSearch]=useState("");
  const doSearch=()=>{const p=mockPatients.find(p=>p.id===idCheck.trim());if(p){setFound(p);setNotFound(false);}else{setFound(null);setNotFound(true);}};
  const regFiltered=mockPatients.filter(p=>p.name.includes(regSearch)||p.id.includes(regSearch));
  if(mode==="choice")return(
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center py-4"><h2 className="text-xl font-bold text-[#1B3A6B]">فتح ملف مريض</h2><p className="text-sm text-[#999] mt-1">اختر الإجراء المطلوب</p></div>
      <div className="grid grid-cols-2 gap-4">
        <button onClick={()=>setMode("search-new")} className="flex flex-col items-center gap-4 p-8 bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all group" style={{border:"2px dashed #0D7377"}}>
          <div className="w-16 h-16 rounded-full bg-[#E6F4F4] flex items-center justify-center group-hover:bg-[#0D7377] transition-colors"><UserPlus size={28} className="text-[#0D7377] group-hover:text-white transition-colors"/></div>
          <div className="text-center"><p className="font-bold text-[#1B3A6B]">تسجيل مريض جديد</p><p className="text-xs text-[#999] mt-1">مريض يزور المركز للمرة الأولى</p></div>
        </button>
        <button onClick={()=>setMode("search-reg")} className="flex flex-col items-center gap-4 p-8 bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all group" style={{border:"1px solid #E0E0E0"}}>
          <div className="w-16 h-16 rounded-full bg-[#EBF3FB] flex items-center justify-center group-hover:bg-[#1B3A6B] transition-colors"><Search size={28} className="text-[#1B3A6B] group-hover:text-white transition-colors"/></div>
          <div className="text-center"><p className="font-bold text-[#1B3A6B]">بدء جلسة لمريض مسجل</p><p className="text-xs text-[#999] mt-1">بحث بالاسم أو رقم الهوية</p></div>
        </button>
      </div>
    </div>
  );
  if(mode==="search-new")return(
    <div className="max-w-xl mx-auto space-y-5">
      <div className="flex items-center gap-3"><button onClick={()=>setMode("choice")} className="text-[#0D7377] hover:underline text-sm">← رجوع</button><h2 className="text-base font-bold text-[#1B3A6B]">التحقق من وجود المريض</h2></div>
      <Card>
        <p className="text-sm text-[#555] mb-4">أدخل رقم الهوية للتحقق من عدم التكرار</p>
        <div className="flex gap-3">
          <input type="text" placeholder="أدخل رقم الهوية..." value={idCheck} onChange={e=>setIdCheck(e.target.value)} onKeyDown={e=>e.key==="Enter"&&doSearch()} className="flex-1 h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}/>
          <Btn variant="secondary" onClick={doSearch}><Search size={16}/>بحث</Btn>
        </div>
        {found&&<div className="mt-4 p-4 rounded-xl" style={{backgroundColor:"#FFF8E1",border:"1px solid #FFE082"}}><p className="text-sm font-bold text-[#E65100] mb-2">⚠️ المريض {found.name} موجود مسبقاً</p><p className="text-xs text-[#555] mb-3">رقم الملف: {found.id}</p><div className="flex gap-2"><Btn variant="secondary" onClick={()=>onNavigate({screen:"new-patient",dept})}>بدء جلسة جديدة له</Btn><Btn variant="outline" onClick={()=>setFound(null)}>إلغاء</Btn></div></div>}
        {notFound&&!found&&<div className="mt-4 p-4 rounded-xl" style={{backgroundColor:"#E8F5E9",border:"1px solid #A5D6A7"}}><p className="text-sm font-bold text-[#388E3C] mb-1">✓ لا يوجد مريض بهذا الرقم</p><p className="text-xs text-[#555] mb-3">الرقم <strong>{idCheck}</strong> سيُستخدم كرقم الملف</p><Btn variant="secondary" onClick={()=>onNavigate({screen:"new-patient",dept})}>المتابعة للتسجيل →</Btn></div>}
      </Card>
    </div>
  );
  return(
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="flex items-center gap-3"><button onClick={()=>setMode("choice")} className="text-[#0D7377] hover:underline text-sm">← رجوع</button><h2 className="text-base font-bold text-[#1B3A6B]">بحث عن مريض مسجل</h2></div>
      <Card>
        <div className="relative mb-4"><Search size={16} className="absolute top-1/2 right-3 -translate-y-1/2 text-[#999]"/><input type="text" placeholder="ابحث بالاسم أو رقم الهوية..." value={regSearch} onChange={e=>setRegSearch(e.target.value)} className="w-full h-11 pr-9 pl-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}/></div>
        {regFiltered.length===0?<div className="text-center py-8"><p className="text-sm text-[#999]">لا يوجد مريض بهذه البيانات</p><button onClick={()=>setMode("search-new")} className="mt-2 text-sm text-[#0D7377] underline">تسجيل مريض جديد</button></div>:(
          <table className="w-full text-sm"><THead cols={["الاسم","رقم الهوية","الجوال","آخر زيارة","الدين",""]}/>
            <tbody>{regFiltered.map((p,i)=><TRow key={p.id} i={i}><TD className="font-medium">{p.name}</TD><TD className="font-mono text-[#555]">{p.id}</TD><TD className="text-[#555]">{p.phone}</TD><TD className="text-[#555]">{p.date}</TD><TD>{p.debt>0?<span className="text-[#D32F2F] font-bold">{fmt(p.debt)}</span>:<Badge color="success">مسدد</Badge>}</TD><TD><Btn small variant="secondary" onClick={()=>onNavigate({screen:"new-patient",dept})}>اختيار</Btn></TD></TRow>)}</tbody>
          </table>
        )}
      </Card>
    </div>
  );
}

// ─── NEW PATIENT ───────────────────────────────────────────────────────────────

function NewPatientScreen({dept,doDeposit,toast}:{dept:string;doDeposit:(dept:string,amount:number,title:string,type:string)=>void;toast:(m:string,t?:any)=>void}){
  const [step,setStep]=useState(1); const [errors,setErrors]=useState<Record<string,string>>({}); const [saving,setSaving]=useState(false); const [saved,setSaved]=useState(false);
  const [form,setForm]=useState({name:"",id:"",phone:"+970",dob:"",email:"",address:"",gender:"",blood:"",allergy:false,allergyDetail:"",chronic:false,chronicDetail:"",insurance:false,insuranceCompany:"",notes:"",price:"",discount:"",discountType:"amount",paid:""});
  const set=(k:string,v:string|boolean)=>{setForm(p=>({...p,[k]:v}));if(errors[k])setErrors(p=>({...p,[k]:""}))};
  const remaining=Math.max(0,(parseFloat(form.price)||0)-(parseFloat(form.discount)||0)-(parseFloat(form.paid)||0));
  const v1=()=>{const e:Record<string,string>={};if(!form.name.trim())e.name="إلزامي";if(!form.id.trim())e.id="إلزامي";if(!form.phone||form.phone==="+970")e.phone="أدخل رقم صحيح";if(!form.dob)e.dob="إلزامي";if(!form.gender)e.gender="اختر الجنس";if(!form.blood)e.blood="إلزامي";setErrors(e);return Object.keys(e).length===0;};
  const v2=()=>{const e:Record<string,string>={};if(!form.price||parseFloat(form.price)<=0)e.price="أدخل سعر الخدمة";setErrors(e);return Object.keys(e).length===0;};
  const handleSave=()=>{setSaving(true);const paid=parseFloat(form.paid)||0;if(paid>0)doDeposit(dept,paid,`دفعة مريض — ${form.name}`,"إيراد مريض");setTimeout(()=>{setSaving(false);setSaved(true);toast("تم تسجيل المريض بنجاح ✓");},800)};
  if(saved)return(<div className="max-w-md mx-auto text-center py-20"><div className="w-20 h-20 rounded-full bg-[#E8F5E9] flex items-center justify-center mx-auto mb-4"><CheckCircle size={40} className="text-[#388E3C]"/></div><h2 className="text-xl font-bold text-[#1B3A6B] mb-2">تم التسجيل بنجاح</h2><p className="text-sm text-[#555] mb-1">رقم الملف: <strong>{form.id}</strong></p>{remaining>0&&<p className="text-sm text-[#D32F2F] mb-4">دين مسجَّل: <strong>{fmt(remaining)}</strong></p>}<Btn variant="secondary" onClick={()=>setSaved(false)}>فتح ملف الجلسة</Btn></div>);
  const errF=(k:string)=>errors[k]&&<p className="text-xs text-[#D32F2F] mt-0.5">{errors[k]}</p>;
  return(
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="flex items-center justify-center gap-4">
        {[{n:1,l:"بيانات المريض"},{n:2,l:"التفاصيل المالية"},{n:3,l:"ملف الجلسة"}].map(({n,l})=>(
          <div key={n} className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${n<step?"bg-[#388E3C] text-white":n===step?"bg-[#0D7377] text-white":"bg-[#E0E0E0] text-[#999]"}`}>{n<step?<Check size={14}/>:n}</div>
            <span className={`text-sm ${n===step?"font-semibold text-[#1B3A6B]":"text-[#999]"}`}>{l}</span>
            {n<3&&<ChevronRight size={16} className="text-[#CCC]"/>}
          </div>
        ))}
      </div>
      {step===1&&(
        <Card title="بيانات المريض الأساسية">
          <div className="grid grid-cols-2 gap-4">
            <div><InputField label="الاسم الكامل" required placeholder="أدخل الاسم الرباعي" value={form.name} onChange={v=>set("name",v)}/>{errF("name")}</div>
            <div><InputField label="رقم الهوية" required placeholder="رقم الهوية 9 أرقام" value={form.id} onChange={v=>set("id",v)}/>{errF("id")}</div>
            <div><InputField label="رقم الجوال" required placeholder="+970599..." value={form.phone} onChange={v=>set("phone",v)}/>{errF("phone")}</div>
            <div><InputField label="تاريخ الميلاد" required type="date" value={form.dob} onChange={v=>set("dob",v)}/>{errF("dob")}</div>
            <InputField label="البريد الإلكتروني" placeholder="example@email.com" value={form.email} onChange={v=>set("email",v)}/>
            <InputField label="العنوان" placeholder="المدينة، الشارع" value={form.address} onChange={v=>set("address",v)}/>
            <div><label className="text-xs font-semibold text-[#555]">الجنس <span className="text-[#D32F2F]">*</span></label><div className="flex gap-4 mt-2">{["ذكر","أنثى"].map(g=><label key={g} className="flex items-center gap-2 cursor-pointer"><input type="radio" name="gender" checked={form.gender===g} onChange={()=>set("gender",g)} className="accent-[#0D7377]"/><span className="text-sm">{g}</span></label>)}</div>{errF("gender")}</div>
            <div><label className="text-xs font-semibold text-[#555]">فصيلة الدم <span className="text-[#D32F2F]">*</span></label><select value={form.blood} onChange={e=>set("blood",e.target.value)} className="h-10 px-3 rounded-lg text-sm w-full outline-none mt-1.5" style={{border:`1px solid ${errors.blood?"#D32F2F":"#CCCCCC"}`,backgroundColor:"#FAFAFA"}}><option value="">اختر فصيلة الدم</option>{["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(b=><option key={b}>{b}</option>)}</select>{errF("blood")}</div>
            {[{k:"allergy",l:"حساسية / موانع دوائية",dk:"allergyDetail"},{k:"chronic",l:"أمراض مزمنة",dk:"chronicDetail"}].map(({k,l,dk})=>(
              <div key={k} className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">{l} <span className="text-[#D32F2F]">*</span></label><div className="flex items-center gap-3"><button onClick={()=>set(k,!(form as any)[k])} className={`w-11 h-6 rounded-full transition-colors relative ${(form as any)[k]?"bg-[#388E3C]":"bg-[#CCC]"}`}><span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${(form as any)[k]?"right-0.5":"left-0.5"}`}/></button><span className="text-sm">{(form as any)[k]?"نعم":"لا"}</span></div>{(form as any)[k]&&<input placeholder="اذكر التفاصيل..." value={(form as any)[dk]} onChange={e=>set(dk,e.target.value)} className="h-10 px-3 rounded-lg text-sm outline-none mt-1" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}/>}</div>
            ))}
            <div className="col-span-2 flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">تأمين صحي <span className="text-[#D32F2F]">*</span></label><div className="flex items-center gap-3"><button onClick={()=>set("insurance",!form.insurance)} className={`w-11 h-6 rounded-full transition-colors relative ${form.insurance?"bg-[#388E3C]":"bg-[#CCC]"}`}><span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${form.insurance?"right-0.5":"left-0.5"}`}/></button><span className="text-sm">{form.insurance?"نعم":"لا"}</span></div>{form.insurance&&<select value={form.insuranceCompany} onChange={e=>set("insuranceCompany",e.target.value)} className="h-10 px-3 rounded-lg text-sm outline-none mt-1" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}><option value="">اختر شركة التأمين</option>{["التأمين الوطني","شركة الأمان","التأمين المتحد"].map(c=><option key={c}>{c}</option>)}</select>}</div>
          </div>
          <div className="flex justify-start mt-6"><Btn variant="secondary" onClick={()=>{if(v1())setStep(2)}}>التالي <ChevronRight size={16}/></Btn></div>
        </Card>
      )}
      {step===2&&(
        <Card title="التفاصيل المالية للجلسة">
          <div className="grid grid-cols-2 gap-4">
            <div><InputField label="سعر الخدمة (₪)" required type="number" placeholder="0" value={form.price} onChange={v=>set("price",v)}/>{errF("price")}</div>
            <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">الخصم</label><div className="flex gap-2"><input type="number" placeholder="0" value={form.discount} onChange={e=>set("discount",e.target.value)} className="flex-1 h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}/><select value={form.discountType} onChange={e=>set("discountType",e.target.value)} className="h-10 px-2 rounded-lg text-sm outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}><option value="amount">₪</option><option value="percent">%</option></select></div></div>
            <InputField label="المبلغ المدفوع (₪)" required type="number" placeholder="0" value={form.paid} onChange={v=>set("paid",v)}/>
            <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">الباقي / الدين (₪)</label><div className={`h-10 px-3 rounded-lg flex items-center text-xl font-bold ${remaining>0?"bg-[#FFEBEE] text-[#D32F2F]":"bg-[#E8F5E9] text-[#388E3C]"}`} style={{border:`1px solid ${remaining>0?"#FFCDD2":"#C8E6C9"}`}}>{fmt(remaining)}</div></div>
          </div>
          {remaining>0&&<p className="text-xs text-[#D32F2F] mt-3 p-2 bg-[#FFEBEE] rounded-lg">⚠️ {fmt(remaining)} سيُضاف كدين على المريض</p>}
          {remaining===0&&(parseFloat(form.price)||0)>0&&<p className="text-xs text-[#388E3C] mt-3 p-2 bg-[#E8F5E9] rounded-lg">✓ مسدد بالكامل</p>}
          <div className="flex justify-between mt-6"><Btn variant="outline" onClick={()=>setStep(1)}><ChevronDown className="rotate-90" size={16}/>رجوع</Btn><Btn variant="secondary" onClick={()=>{if(v2())setStep(3)}}>التالي <ChevronRight size={16}/></Btn></div>
        </Card>
      )}
      {step===3&&(
        <Card title="ملف الجلسة الطبية">
          <div className="space-y-4">
            <InputField label="التشخيص"><select className="h-10 px-3 rounded-lg text-sm w-full outline-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}}><option>اختر التشخيص...</option><option>التهاب الزائدة</option><option>كسر في الذراع</option><option>جرح خياطة</option></select></InputField>
            <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">وصف الجلسة</label><textarea rows={3} className="px-3 py-2 rounded-lg text-sm outline-none resize-none" style={{border:"1px solid #CCCCCC",backgroundColor:"#FAFAFA"}} placeholder="وصف مفصَّل للجلسة..."/></div>
            <div className="border-2 border-dashed border-[#CCC] rounded-xl p-6 text-center hover:border-[#0D7377] transition-colors cursor-pointer"><CloudUpload size={24} className="mx-auto text-[#CCC] mb-1"/><p className="text-sm text-[#555]">اسحب الملفات أو <span className="text-[#0D7377] font-medium">اختر ملفاً</span></p></div>
          </div>
          <div className="flex justify-between mt-6"><Btn variant="outline" onClick={()=>setStep(2)}><ChevronDown className="rotate-90" size={16}/>رجوع</Btn><Btn variant="success" loading={saving} onClick={handleSave}><Save size={16}/>حفظ الجلسة</Btn></div>
        </Card>
      )}
    </div>
  );
}

// ─── PATIENT FILE ──────────────────────────────────────────────────────────────

function PatientFileScreen(){
  const p=mockPatients[0];
  const sessions=[{id:1,date:"15/06/2026",dept:"الجراحة",diagnosis:"التهاب الزائدة",price:2500,paid:1300,debt:1200,status:"partial"},{id:2,date:"20/04/2026",dept:"الجراحة",diagnosis:"جرح خياطة",price:500,paid:500,debt:0,status:"paid"},{id:3,date:"05/02/2026",dept:"المختبر",diagnosis:"تحاليل دورية",price:300,paid:300,debt:0,status:"paid"}];
  const [drawerSess,setDrawerSess]=useState<any>(null);
  return(
    <div className="grid grid-cols-3 gap-5">
      <div className="space-y-4">
        <Card><div className="text-center mb-4"><div className="w-16 h-16 rounded-full bg-[#EBF3FB] flex items-center justify-center mx-auto mb-3"><span className="text-2xl font-bold text-[#1B3A6B]">{p.name[0]}</span></div><h2 className="text-base font-bold">{p.name}</h2><p className="text-xs text-[#999]">رقم الملف: {p.id}</p></div>
          <div className="space-y-2 text-sm">{[["العمر",`${p.age} سنة`],["الجوال",p.phone],["فصيلة الدم",p.blood],["التأمين",p.insurance?"مؤمَّن":"غير مؤمَّن"],["آخر زيارة",p.date]].map(([k,v])=><div key={k} className="flex justify-between"><span className="text-[#999]">{k}</span><span className="font-medium">{v}</span></div>)}</div>
        </Card>
        {p.debt>0&&<div className="rounded-xl p-4" style={{backgroundColor:"#FFEBEE",border:"1px solid #FFCDD2"}}><p className="text-xs font-semibold text-[#D32F2F] mb-1">إجمالي الدين</p><p className="text-2xl font-bold text-[#D32F2F]">{fmt(p.debt)}</p></div>}
        <Btn variant="secondary" full><Plus size={16}/>بدء جلسة جديدة</Btn>
        <Btn variant="outline" full><Printer size={16}/>طباعة الملف</Btn>
      </div>
      <div className="col-span-2">
        <Card title="سجل الجلسات">
          <table className="w-full text-sm"><THead cols={["التاريخ","القسم","التشخيص","المبلغ","المدفوع","الدين","الحالة",""]}/>
            <tbody>{sessions.map((s,i)=><TRow key={s.id} i={i}><TD className="text-[#555]">{s.date}</TD><TD><Badge color="info">{s.dept}</Badge></TD><TD>{s.diagnosis}</TD><TD className="font-medium">{fmt(s.price)}</TD><TD className="text-[#388E3C] font-medium">{fmt(s.paid)}</TD><TD>{s.debt>0?<span className="text-[#D32F2F] font-bold">{fmt(s.debt)}</span>:<span className="text-[#388E3C]">—</span>}</TD><TD><Badge color={s.status==="paid"?"success":"warning"}>{s.status==="paid"?"مسدد":"جزئي"}</Badge></TD><TD><Btn small variant="ghost" onClick={()=>setDrawerSess(s)}><Eye size={14}/></Btn></TD></TRow>)}</tbody>
          </table>
        </Card>
      </div>
      <SessionDrawer open={!!drawerSess} onClose={()=>setDrawerSess(null)} session={drawerSess}/>
    </div>
  );
}

// ─── LAB SESSION ───────────────────────────────────────────────────────────────

function LabSessionScreen({toast}:{toast:(m:string,t?:any)=>void}){
  const [selected,setSelected]=useState<string[]>([]); const [sessions,setSessions]=useState(labSessions); const [resultsModal,setResultsModal]=useState<number|null>(null); const [deliverConfirm,setDeliverConfirm]=useState<number|null>(null);
  const total=selected.reduce((s,id)=>s+(initialLabTests.find(t=>t.code===id)?.price||0),0);
  const toggle=(id:string)=>setSelected(p=>p.includes(id)?p.filter(x=>x!==id):[...p,id]);
  const deliver=(id:number)=>{setSessions(p=>p.map(s=>s.id===id?{...s,status:"done" as const}:s));setDeliverConfirm(null);toast("تم تسليم التقرير بنجاح ✓")};
  return(
    <div className="grid grid-cols-5 gap-5">
      <div className="col-span-2 space-y-4">
        <Card title="اختيار الفحوصات">
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {initialLabTests.slice(0,10).map(t=>(
              <label key={t.code} className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${selected.includes(t.code)?"bg-[#E6F4F4] border-[#0D7377]":"bg-[#FAFAFA] border-[#E0E0E0]"}`} style={{border:"1px solid"}}>
                <div className="flex items-center gap-2"><input type="checkbox" checked={selected.includes(t.code)} onChange={()=>toggle(t.code)} className="accent-[#0D7377]"/><div><p className="text-sm font-medium">{t.name}</p><p className="text-xs text-[#999]">{t.code} · {t.kit}</p></div></div>
                <span className="text-sm font-bold text-[#0D7377]">{fmt(t.price)}</span>
              </label>
            ))}
          </div>
          {selected.length>0&&<div className="mt-4 p-3 rounded-lg" style={{backgroundColor:"#E6F4F4",border:"1px solid #B2DFDB"}}><div className="flex justify-between text-sm font-bold text-[#0D7377] mb-2"><span>{selected.length} فحص | {fmt(total)}</span></div><Btn variant="secondary" full><Plus size={16}/>بدء الجلسة</Btn></div>}
        </Card>
      </div>
      <div className="col-span-3 space-y-4">
        <Card title="قيد الإنجاز">
          {sessions.filter(s=>s.status==="pending").length===0?<EmptyState msg="لا توجد فحوصات قيد الإنجاز"/>:(
            <div className="space-y-3">{sessions.filter(s=>s.status==="pending").map(s=>(
              <div key={s.id} className="flex items-center justify-between p-3 rounded-xl" style={{backgroundColor:"#FFF8E1",border:"1px solid #FFE082"}}>
                <div><p className="text-sm font-semibold">{s.patient}</p><div className="flex gap-1 mt-1 flex-wrap">{s.tests.map(t=><Badge key={t} color="warning">{t}</Badge>)}</div></div>
                <div className="flex flex-col items-end gap-2"><span className="text-xs text-[#999] flex items-center gap-1"><Clock size={12}/>{s.time}</span><Btn small variant="secondary" onClick={()=>setResultsModal(s.id)}>إدخال النتائج</Btn></div>
              </div>
            ))}</div>
          )}
        </Card>
        <Card title="الفحوصات المُنجزة">
          {sessions.filter(s=>s.status==="done").length===0?<EmptyState msg="لا توجد فحوصات مُنجزة بعد"/>:(
            <div className="space-y-2">{sessions.filter(s=>s.status==="done").map(s=>(
              <div key={s.id} className="flex items-center justify-between p-3 rounded-xl" style={{backgroundColor:"#E8F5E9",border:"1px solid #A5D6A7"}}>
                <div><p className="text-sm font-semibold">{s.patient}</p><div className="flex gap-1 mt-1 flex-wrap">{s.tests.map(t=><Badge key={t} color="success">{t}</Badge>)}</div></div>
                <div className="flex items-center gap-2"><Badge color="success"><CheckCircle size={12}/>مُسلَّم</Badge><Btn small variant="ghost"><Printer size={14}/></Btn></div>
              </div>
            ))}</div>
          )}
        </Card>
      </div>
      <Modal open={resultsModal!==null} onClose={()=>setResultsModal(null)} title="إدخال نتائج الفحوصات" wide
        footer={<><Btn variant="primary"><Printer size={16}/>طباعة التقرير</Btn><Btn variant="success" onClick={()=>{setDeliverConfirm(resultsModal);setResultsModal(null)}}><Check size={16}/>تم التسليم</Btn><Btn variant="outline" onClick={()=>setResultsModal(null)}>إغلاق</Btn></>}>
        <table className="w-full text-sm"><THead cols={["الفحص","النتيجة","الوحدة","المعدل الطبيعي","الحالة"]}/>
          <tbody>{["تعداد الدم الكامل","وظائف الكبد"].map((t,i)=><TRow key={t} i={i}><TD className="font-medium">{t}</TD><TD><input className="h-8 w-24 px-2 rounded text-sm outline-none" style={{border:"1px solid #CCC"}} placeholder="أدخل..."/></TD><TD className="text-[#555]">g/dL</TD><TD className="text-[#555]">12.0–16.0</TD><TD><select className="h-8 px-2 rounded text-xs outline-none" style={{border:"1px solid #CCC"}}><option>طبيعي</option><option>غير طبيعي</option></select></TD></TRow>)}</tbody>
        </table>
      </Modal>
      <ConfirmModal open={deliverConfirm!==null} onClose={()=>setDeliverConfirm(null)} onConfirm={()=>deliver(deliverConfirm!)} title="تأكيد تسليم التقرير" message="هل تأكد من تسليم نتائج الفحص للمريض؟"/>
    </div>
  );
}

// ─── MERGED DEPT SCREEN (Drawer + Stats + Charts + Employees + Transactions) ──

function DrawerMovementsScreen({dept,drawer,invoices,setInvoices,doWithdraw,doDeposit,toast}:{dept:string;drawer:DrawerState;invoices:Invoice[];setInvoices:React.Dispatch<React.SetStateAction<Invoice[]>>;doWithdraw:(amount:number,title:string,cat:string,ben?:string)=>void;doDeposit:(amount:number,title:string,type:string)=>void;toast:(m:string,t?:any)=>void}){
  const [tab,setTab]=useState<"all"|"in"|"out"|"invoices">("all");
  const [showW,setShowW]=useState(false); const [showD,setShowD]=useState(false);
  const [settleModal,setSettleModal]=useState<Invoice|null>(null); const [settleAmount,setSettleAmount]=useState(""); const [settling,setSettling]=useState(false);
  const deptInfo=DEPARTMENTS.find(d=>d.id===dept); const deptEmployees=initialEmployees.filter(e=>e.dept===dept);
  const txs=tab==="all"?drawer.txs:tab==="in"?drawer.txs.filter(t=>t.type==="in"):drawer.txs.filter(t=>t.type==="out");
  const deptInvoices=invoices.filter(i=>i.dept===dept);
  const handleSettle=()=>{
    if(!settleModal||!settleAmount)return;const paid=parseFloat(settleAmount);setSettling(true);
    setTimeout(()=>{doWithdraw(paid,`دفع فاتورة #${settleModal.id} — ${settleModal.company}`,"دفع فاتورة شركة",settleModal.company);setInvoices(p=>p.map(inv=>inv.id===settleModal.id?{...inv,paid:inv.paid+paid,remaining:Math.max(0,inv.remaining-paid),status:(inv.remaining-paid<=0?"paid":"partial") as "paid"|"partial"|"unpaid"}:inv));setSettling(false);setSettleModal(null);setSettleAmount("");toast(`تم تسديد ${fmt(paid)} لـ ${settleModal.company}`)},700);
  };
  const statusBadge=(s:string)=>s==="paid"?<Badge color="success">مسدد كامل</Badge>:s==="partial"?<Badge color="warning">جزئي</Badge>:<Badge color="danger">غير مسدد</Badge>;
  const totalRevToday = 1800; const totalRevMonth = 22300; const totalWithdrawals = drawer.txs.filter(t=>t.type==="out").reduce((s,t)=>s+t.amount,0)+35600;
  return(
    <div className="space-y-5">
      {/* Drawer Card */}
      <div className="rounded-2xl p-6 text-white" style={{background:`linear-gradient(135deg,${C.primary} 0%,#0D4480 100%)`}}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-white/70 text-xs mb-1">الجرار — {deptInfo?.name}</p>
            <p className={`text-4xl font-bold ${drawer.balance===0?"text-[#FF5252]":drawer.balance<2000?"text-[#FFC107]":"text-white"}`}>{fmt(drawer.balance)}</p>
            <p className="text-white/60 text-xs mt-1">الرصيد الحالي</p>
          </div>
          <div className="flex gap-3">
            <button onClick={()=>setShowD(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium bg-[#0D7377] hover:bg-[#0a5c60] transition-colors"><ArrowUpCircle size={16}/>إضافة للجرار</button>
            <button onClick={()=>setShowW(true)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors" style={{backgroundColor:"rgba(255,255,255,0.15)",border:"1px solid rgba(255,255,255,0.3)"}}><ArrowDownCircle size={16}/>سحب من الجرار</button>
          </div>
        </div>
        <div className="mt-4 space-y-1.5">
          {drawer.txs.slice(0,4).map(tx=>(
            <div key={tx.id} className="flex items-center gap-3 text-xs py-1.5 border-t border-white/10">
              {tx.type==="in"?<ArrowUpCircle size={13} className="text-[#81C784]"/>:<ArrowDownCircle size={13} className="text-[#EF9A9A]"/>}
              <span className="flex-1 text-white/80 truncate">{tx.title}</span>
              <span className="text-white/60 text-[10px]">{tx.time}</span>
              <span className={`font-bold ${tx.type==="in"?"text-[#81C784]":"text-[#EF9A9A]"}`}>{tx.type==="in"?"+":"-"}{fmt(tx.amount)}</span>
            </div>
          ))}
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-3 gap-4">
        <KPICard title="عدد المرضى اليوم / الإجمالي" value="12 / 342" Icon={Users} color="secondary"/>
        <KPICard title="إيرادات اليوم / الشهر" value={`${fmt(totalRevToday)} / ${fmt(totalRevMonth)}`} Icon={TrendingUp} color="secondary" trend={{val:"+15%",up:true}}/>
        <KPICard title="إجمالي السحوبات" value={fmt(totalWithdrawals)} Icon={ArrowDownCircle} color="danger"/>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-2 gap-4">
        <Card title="حركة الجرار — آخر 14 يوم">
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={drawerHistory14} margin={{top:5,right:0,left:-10,bottom:5}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0"/>
              <XAxis dataKey="date" tick={{fontSize:9,fill:"#555"}}/><YAxis tick={{fontSize:9,fill:"#555"}}/>
              <Tooltip formatter={(v:number)=>fmt(v)}/>
              <Area type="monotone" dataKey="رصيد" name={`${dept}-bal`} stroke={C.secondary} fill="#E6F4F4" strokeWidth={2}/>
            </AreaChart>
          </ResponsiveContainer>
        </Card>
        <Card title="الإيرادات اليومية — آخر 14 يوم">
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={drawerHistory14} margin={{top:5,right:0,left:-10,bottom:5}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0"/>
              <XAxis dataKey="date" tick={{fontSize:9,fill:"#555"}}/><YAxis tick={{fontSize:9,fill:"#555"}}/>
              <Tooltip formatter={(v:number)=>fmt(v)}/>
              <Bar dataKey="إيرادات" name={`${dept}-rev`} fill={C.success} radius={[3,3,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Employees */}
      <Card title="موظفو القسم">
        <table className="w-full text-sm">
          <THead cols={["الموظف","الدور","سحوبات هذا الشهر",""]}/>
          <tbody>{deptEmployees.map((e,i)=><TRow key={e.id} i={i}><TD className="font-medium">{e.name}</TD><TD className="text-[#555]">{e.role}</TD><TD className="text-[#FF8F00] font-medium">{fmt(e.expenses)}</TD><TD><Btn small variant="outline" onClick={()=>setShowW(true)}>سحب سريع</Btn></TD></TRow>)}</tbody>
        </table>
      </Card>

      {/* Transactions Tabs */}
      <div className="flex gap-2 flex-wrap">
        {[{k:"all",l:"كل الحركات"},{k:"in",l:"الإضافات ↑"},{k:"out",l:"السحوبات ↓"},{k:"invoices",l:"فواتير الشركات"}].map(t=>(
          <button key={t.k} onClick={()=>setTab(t.k as any)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${tab===t.k?"bg-[#1B3A6B] text-white":"bg-white text-[#555] hover:bg-[#EBF3FB]"}`} style={{border:"1px solid #E0E0E0"}}>{t.l}</button>
        ))}
        <div className="mr-auto flex gap-2">
          <Btn small variant="secondary" onClick={()=>setShowW(true)}><ArrowDownCircle size={14}/>تسجيل سحب</Btn>
          <Btn small variant="ghost"><Download size={14}/>تصدير</Btn>
        </div>
      </div>

      {tab!=="invoices"&&(
        <Card title={`حركات الجرار${tab==="in"?" — الإضافات":tab==="out"?" — السحوبات":""}`}>
          {txs.length===0?<EmptyState/>:(
            <table className="w-full text-sm"><THead cols={["الوقت","النوع","العنوان","التصنيف","المستفيد","المبلغ","الرصيد بعد"]}/>
              <tbody>{txs.map((tx,i)=><TRow key={tx.id} i={i}>
                <TD className="text-[#555] text-xs">{tx.time}</TD>
                <TD>{tx.type==="in"?<span className="flex items-center gap-1 text-[#388E3C] font-semibold text-xs"><ArrowUpCircle size={12}/>إضافة</span>:<span className="flex items-center gap-1 text-[#D32F2F] font-semibold text-xs"><ArrowDownCircle size={12}/>سحب</span>}</TD>
                <TD className="font-medium">{tx.title}</TD>
                <TD><Badge color={tx.category==="إيداع في البنك"?"info":tx.type==="in"?"success":"warning"}>{tx.category}</Badge></TD>
                <TD className="text-[#555]">{tx.beneficiary||"—"}</TD>
                <TD className={`font-bold ${tx.type==="in"?"text-[#388E3C]":"text-[#D32F2F]"}`}>{tx.type==="in"?"+":"-"}{fmt(tx.amount)}</TD>
                <TD className="font-mono text-[#555]">{fmt(tx.balance)}</TD>
              </TRow>)}</tbody>
            </table>
          )}
        </Card>
      )}

      {tab==="invoices"&&(
        <Card title="فواتير الشركات" action={<Btn small variant="secondary"><Plus size={14}/>فاتورة جديدة</Btn>}>
          {deptInvoices.length===0?<EmptyState msg="لا توجد فواتير"/>:(
            <table className="w-full text-sm"><THead cols={["رقم الفاتورة","الشركة","التاريخ","الإجمالي","المدفوع","الباقي","الحالة",""]}/>
              <tbody>{deptInvoices.map((inv,i)=><TRow key={inv.id} i={i}>
                <TD className="font-mono font-bold text-[#1B3A6B]">{inv.id}</TD><TD>{inv.company}</TD><TD className="text-[#555]">{inv.date}</TD>
                <TD className="font-semibold">{fmt(inv.total)}</TD><TD className="text-[#388E3C] font-medium">{fmt(inv.paid)}</TD>
                <TD>{inv.remaining>0?<span className="text-[#D32F2F] font-bold">{fmt(inv.remaining)}</span>:<span className="text-[#999]">—</span>}</TD>
                <TD>{statusBadge(inv.status)}</TD>
                <TD><div className="flex gap-1"><Btn small variant="ghost"><Printer size={14}/></Btn>{inv.status!=="paid"&&<Btn small variant="secondary" onClick={()=>setSettleModal(inv)}>تسديد</Btn>}</div></TD>
              </TRow>)}</tbody>
            </table>
          )}
        </Card>
      )}

      <Modal open={!!settleModal} onClose={()=>setSettleModal(null)} title="تسديد فاتورة شراء"
        footer={<><Btn variant="success" loading={settling} onClick={handleSettle}><Check size={16}/>تأكيد</Btn><Btn variant="outline" onClick={()=>setSettleModal(null)}>إلغاء</Btn></>}>
        {settleModal&&<div className="space-y-4"><div className="p-3 rounded-xl bg-[#EBF3FB]"><p className="text-sm">الشركة: <strong>{settleModal.company}</strong></p><p className="text-sm mt-1">الباقي: <strong className="text-[#D32F2F]">{fmt(settleModal.remaining)}</strong></p><p className="text-xs text-[#555] mt-1">رصيد الجرار: <strong className="text-[#0D7377]">{fmt(drawer.balance)}</strong></p></div><InputField label="المبلغ المُسدَّد (₪)" required type="number" placeholder="0" value={settleAmount} onChange={setSettleAmount}/><p className="text-xs text-[#999]">سيُخصم من جرار القسم تلقائياً</p></div>}
      </Modal>
      <WithdrawModal open={showW} onClose={()=>setShowW(false)} dept={dept} balance={drawer.balance} onConfirm={(a,t,c,b)=>{doWithdraw(a,t,c,b);toast(`تم تسجيل سحب ${fmt(a)}`,"success")}}/>
      <DepositModal open={showD} onClose={()=>setShowD(false)} dept={dept} balance={drawer.balance} onConfirm={(a,t,ty)=>{doDeposit(a,t,ty);toast(`تم تسجيل إضافة ${fmt(a)} للجرار`,"success")}}/>
    </div>
  );
}

// ─── TEST CATALOG (full CRUD) ──────────────────────────────────────────────────

function TestCatalogScreen({toast}:{toast:(m:string,t?:any)=>void}){
  const [tests,setTests]=useState<LabTest[]>(initialLabTests);
  const [search,setSearch]=useState("");
  const [addModal,setAddModal]=useState(false);
  const [editItem,setEditItem]=useState<LabTest|null>(null);
  const [delConfirm,setDelConfirm]=useState<LabTest|null>(null);
  const [importModal,setImportModal]=useState(false);
  const [importStep,setImportStep]=useState(1);
  const [normalRanges,setNormalRanges]=useState<NormalRange[]>([{param:"",unit:"",min:"",max:"",note:""}]);
  const [form,setForm]=useState({code:"",name:"",nameEn:"",cat:"تحاليل الدم",price:"",kit:"",time:"",timeUnit:"ساعة",desc:"",notes:""});
  const filtered=tests.filter(t=>t.name.includes(search)||t.code.toLowerCase().includes(search.toLowerCase())||t.nameEn.toLowerCase().includes(search.toLowerCase()));
  const openAdd=()=>{setForm({code:"",name:"",nameEn:"",cat:"تحاليل الدم",price:"",kit:"",time:"",timeUnit:"ساعة",desc:"",notes:""});setNormalRanges([{param:"",unit:"",min:"",max:"",note:""}]);setEditItem(null);setAddModal(true)};
  const openEdit=(t:LabTest)=>{setForm({code:t.code,name:t.name,nameEn:t.nameEn,cat:t.cat,price:String(t.price),kit:t.kit,time:t.time,timeUnit:"ساعة",desc:"",notes:""});setNormalRanges(t.normalRanges||[{param:"",unit:"",min:"",max:"",note:""}]);setEditItem(t);setAddModal(true)};
  const handleSave=()=>{
    if(!form.name.trim()||!form.code.trim()||!form.price)return;
    if(editItem){setTests(p=>p.map(t=>t.id===editItem.id?{...t,...form,price:parseFloat(form.price),normalRanges}:t));toast("تم تحديث الفحص بنجاح ✓");}
    else{setTests(p=>[{id:Date.now(),code:form.code,name:form.name,nameEn:form.nameEn,cat:form.cat,price:parseFloat(form.price),kit:form.kit,time:form.time,normalRanges},...p]);toast("تم إضافة الفحص بنجاح ✓");}
    setAddModal(false);
  };
  const handleDel=()=>{setTests(p=>p.filter(t=>t.id!==delConfirm?.id));setDelConfirm(null);toast("تم الحذف","warning")};
  const addRange=()=>setNormalRanges(p=>[...p,{param:"",unit:"",min:"",max:"",note:""}]);
  const setRange=(i:number,k:keyof NormalRange,v:string)=>setNormalRanges(p=>p.map((r,idx)=>idx===i?{...r,[k]:v}:r));
  const delRange=(i:number)=>setNormalRanges(p=>p.filter((_,idx)=>idx!==i));
  return(
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-xs"><Search size={15} className="absolute top-1/2 right-3 -translate-y-1/2 text-[#999]"/><input type="text" placeholder="بحث بالاسم أو الرمز..." value={search} onChange={e=>setSearch(e.target.value)} className="w-full h-9 pr-9 pl-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/></div>
        <div className="flex gap-2">
          <Btn small variant="ghost" onClick={()=>toast("جارٍ تحميل Excel...","info")}><Download size={14}/>تصدير Excel</Btn>
          <Btn small variant="outline" onClick={()=>{setImportStep(1);setImportModal(true)}}><FileDown size={14}/>استيراد من Excel</Btn>
          <Btn small variant="secondary" onClick={openAdd}><Plus size={14}/>إضافة فحص جديد</Btn>
        </div>
      </div>
      <Card title={`دليل الفحوصات والأسعار — ${filtered.length} فحص`}>
        <table className="w-full text-sm">
          <THead cols={["#","اسم الفحص","الرمز","الفئة","السعر (₪)","Kit المرتبط","وقت الإنجاز","إجراءات"]}/>
          <tbody>
            {filtered.map((t,i)=>(
              <TRow key={t.id} i={i}>
                <TD className="text-[#999] font-mono">{i+1}</TD>
                <TD><div><p className="font-medium">{t.name}</p><p className="text-xs text-[#999]">{t.nameEn}</p></div></TD>
                <TD><span className="font-mono font-bold text-[#0D7377] text-xs">{t.code}</span></TD>
                <TD><Badge color="info">{t.cat}</Badge></TD>
                <TD className="font-bold text-[#0D7377]">{fmt(t.price)}</TD>
                <TD className="text-[#555]">{t.kit}</TD>
                <TD><Badge color={t.time==="فوري"?"success":"neutral"}>{t.time}</Badge></TD>
                <TD><div className="flex gap-1"><Btn small variant="ghost" onClick={()=>openEdit(t)}><Edit size={14}/></Btn><button onClick={()=>setDelConfirm(t)} className="p-1.5 rounded hover:bg-[#FFEBEE] text-[#D32F2F] transition-colors"><Trash2 size={14}/></button></div></TD>
              </TRow>
            ))}
          </tbody>
        </table>
        {filtered.length===0&&<EmptyState msg="لا توجد نتائج"/>}
      </Card>

      {/* Add/Edit Modal */}
      <Modal open={addModal} onClose={()=>setAddModal(false)} title={editItem?`تعديل فحص: ${editItem.name}`:"إضافة فحص جديد"} wide
        footer={<><Btn variant="secondary" onClick={handleSave} disabled={!form.name.trim()||!form.code.trim()||!form.price}><Save size={16}/>حفظ الفحص</Btn><Btn variant="outline" onClick={()=>setAddModal(false)}>إلغاء</Btn></>}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <InputField label="اسم الفحص بالعربي" required placeholder="تعداد الدم الكامل" value={form.name} onChange={v=>setForm(p=>({...p,name:v}))}/>
            <InputField label="اسم الفحص بالإنجليزي" placeholder="Complete Blood Count" value={form.nameEn} onChange={v=>setForm(p=>({...p,nameEn:v}))}/>
            <InputField label="رمز الفحص (Code)" required placeholder="CBC" value={form.code} onChange={v=>setForm(p=>({...p,code:v}))}/>
            <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">الفئة <span className="text-[#D32F2F]">*</span></label><select value={form.cat} onChange={e=>setForm(p=>({...p,cat:e.target.value}))} className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}>{LAB_CATS.map(c=><option key={c}>{c}</option>)}</select></div>
            <InputField label="السعر (₪)" required type="number" placeholder="0" value={form.price} onChange={v=>setForm(p=>({...p,price:v}))}/>
            <InputField label="Kit المرتبط" placeholder="CBC Kit" value={form.kit} onChange={v=>setForm(p=>({...p,kit:v}))}/>
            <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">وقت الإنجاز <span className="text-[#D32F2F]">*</span></label><div className="flex gap-2"><input type="text" placeholder="مثال: 2" value={form.time} onChange={e=>setForm(p=>({...p,time:e.target.value}))} className="flex-1 h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/><select value={form.timeUnit} onChange={e=>setForm(p=>({...p,timeUnit:e.target.value}))} className="h-10 px-2 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}><option>ساعة</option><option>يوم</option><option>فوري</option></select></div></div>
            <div className="col-span-2 flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">وصف الفحص</label><textarea rows={2} value={form.desc} onChange={e=>setForm(p=>({...p,desc:e.target.value}))} className="px-3 py-2 rounded-lg text-sm outline-none resize-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/></div>
          </div>
          {/* Normal Ranges */}
          <div className="border-t border-[#E0E0E0] pt-4">
            <div className="flex items-center justify-between mb-3"><p className="text-sm font-bold text-[#1B3A6B]">قيم المرجع / المعدلات الطبيعية</p><Btn small variant="outline" onClick={addRange}><Plus size={12}/>إضافة معامل</Btn></div>
            {normalRanges.map((r,i)=>(
              <div key={i} className="grid grid-cols-6 gap-2 mb-2 items-center">
                <input placeholder="اسم المعامل" value={r.param} onChange={e=>setRange(i,"param",e.target.value)} className="col-span-2 h-9 px-2 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/>
                <input placeholder="الوحدة" value={r.unit} onChange={e=>setRange(i,"unit",e.target.value)} className="h-9 px-2 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/>
                <input placeholder="الأدنى" value={r.min} onChange={e=>setRange(i,"min",e.target.value)} className="h-9 px-2 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/>
                <input placeholder="الأعلى" value={r.max} onChange={e=>setRange(i,"max",e.target.value)} className="h-9 px-2 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/>
                <button onClick={()=>delRange(i)} className="p-2 rounded hover:bg-[#FFEBEE] text-[#D32F2F] transition-colors"><Trash2 size={13}/></button>
              </div>
            ))}
          </div>
        </div>
      </Modal>

      {/* Delete Confirm */}
      <Modal open={!!delConfirm} onClose={()=>setDelConfirm(null)} title="حذف الفحص"
        footer={<><Btn variant="danger" onClick={handleDel}><Trash2 size={16}/>حذف</Btn><Btn variant="outline" onClick={()=>setDelConfirm(null)}>إلغاء</Btn></>}>
        <div className="text-center py-4">
          <div className="w-12 h-12 rounded-full bg-[#FFEBEE] flex items-center justify-center mx-auto mb-3"><AlertTriangle size={24} className="text-[#D32F2F]"/></div>
          <p className="text-sm text-[#555] leading-relaxed">هل أنت متأكد من حذف فحص <strong>"{delConfirm?.name}"</strong>؟<br/><span className="text-xs text-[#999]">⚠️ إن كان مرتبطاً بجلسات سابقة لن يُحذف من السجلات القديمة.</span></p>
        </div>
      </Modal>

      {/* Excel Import Modal */}
      <Modal open={importModal} onClose={()=>setImportModal(false)} title="استيراد فحوصات من ملف Excel" wide
        footer={importStep===3?<><Btn variant="secondary" onClick={()=>{toast("تم استيراد 25 فحص بنجاح ✓");setImportModal(false)}}>استيراد الآن</Btn><Btn variant="outline" onClick={()=>setImportModal(false)}>إلغاء</Btn></>:importStep===2?<><Btn variant="secondary" onClick={()=>setImportStep(3)}>التحقق من البيانات</Btn><Btn variant="outline" onClick={()=>setImportStep(1)}>رجوع</Btn></>:<></>}>
        {importStep===1&&(
          <div className="space-y-4">
            <div className="border-2 border-dashed border-[#CCC] rounded-xl p-10 text-center hover:border-[#0D7377] transition-colors cursor-pointer" onClick={()=>setImportStep(2)}>
              <FileDown size={36} className="mx-auto text-[#CCC] mb-3"/>
              <p className="text-sm font-medium text-[#555]">اسحب ملف Excel هنا أو <span className="text-[#0D7377]">انقر للاختيار</span></p>
              <p className="text-xs text-[#999] mt-1">يقبل: .xlsx .xls .csv</p>
            </div>
            <div className="text-center"><button className="text-sm text-[#0D7377] underline">⬇️ تحميل نموذج Excel الجاهز</button></div>
          </div>
        )}
        {importStep===2&&(
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-[#E8F5E9]"><p className="text-sm font-medium text-[#388E3C]">✓ تم تحميل الملف: فحوصات_المختبر.xlsx</p></div>
            <p className="text-xs font-bold text-[#555] mb-2">ربط الأعمدة بحقول النظام:</p>
            {[["العمود A","اسم الفحص"],["العمود B","الرمز"],["العمود C","السعر (₪)"],["العمود D","الفئة"]].map(([col,field])=>(
              <div key={col} className="flex items-center gap-3"><span className="text-xs text-[#555] w-20">{col}</span><ChevronRight size={14} className="text-[#CCC]"/><select className="flex-1 h-9 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}} defaultValue={field}>{["اسم الفحص","الرمز","السعر (₪)","الفئة","Kit المرتبط","وقت الإنجاز","تجاهل"].map(o=><option key={o}>{o}</option>)}</select></div>
            ))}
          </div>
        )}
        {importStep===3&&(
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-[#E8F5E9]"><p className="text-sm font-bold text-[#388E3C]">✓ تم التحقق: 25 فحص جاهز للاستيراد</p></div>
            <div className="p-3 rounded-xl bg-[#FFF8E1]"><p className="text-xs font-bold text-[#FF8F00] mb-1">تحذيرات (1):</p><p className="text-xs text-[#555]">الصف 12: السعر فارغ — سيُستورد بسعر 0</p></div>
            <p className="text-xs text-[#999]">سيتم إضافة 25 فحص لقائمة الفحوصات الحالية</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

// ─── IMAGE CATALOG (full CRUD) ─────────────────────────────────────────────────

function ImageCatalogScreen({toast}:{toast:(m:string,t?:any)=>void}){
  const [images,setImages]=useState<RadImage[]>(initialRadImages);
  const [search,setSearch]=useState("");
  const [addModal,setAddModal]=useState(false);
  const [editItem,setEditItem]=useState<RadImage|null>(null);
  const [delConfirm,setDelConfirm]=useState<RadImage|null>(null);
  const [form,setForm]=useState<RadImage>({id:0,code:"",name:"",device:"X-Ray",price:0,timeVal:"",timeUnit:"دقيقة",instructions:"",notes:""});
  const filtered=images.filter(t=>t.name.includes(search)||t.code.toLowerCase().includes(search.toLowerCase()));
  const openAdd=()=>{setForm({id:0,code:"",name:"",device:"X-Ray",price:0,timeVal:"",timeUnit:"دقيقة",instructions:"",notes:""});setEditItem(null);setAddModal(true)};
  const openEdit=(t:RadImage)=>{setForm({...t});setEditItem(t);setAddModal(true)};
  const handleSave=()=>{
    if(!form.name.trim()||!form.price)return;
    if(editItem){setImages(p=>p.map(t=>t.id===editItem.id?{...form,id:t.id}:t));toast("تم تحديث نوع الصورة ✓");}
    else{setImages(p=>[{...form,id:Date.now()},...p]);toast("تم إضافة نوع الصورة ✓");}
    setAddModal(false);
  };
  return(
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-xs"><Search size={15} className="absolute top-1/2 right-3 -translate-y-1/2 text-[#999]"/><input type="text" placeholder="بحث بالاسم أو الرمز..." value={search} onChange={e=>setSearch(e.target.value)} className="w-full h-9 pr-9 pl-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/></div>
        <div className="flex gap-2">
          <Btn small variant="ghost" onClick={()=>toast("جارٍ تحميل Excel...","info")}><Download size={14}/>تصدير Excel</Btn>
          <Btn small variant="secondary" onClick={openAdd}><Plus size={14}/>إضافة صورة جديدة</Btn>
        </div>
      </div>
      <Card title={`دليل الصور والأسعار — ${filtered.length} نوع`}>
        <table className="w-full text-sm">
          <THead cols={["#","نوع الصورة","الرمز","الجهاز","السعر (₪)","وقت الإنجاز","ملاحظات","إجراءات"]}/>
          <tbody>{filtered.map((t,i)=>(
            <TRow key={t.id} i={i}>
              <TD className="text-[#999] font-mono">{i+1}</TD>
              <TD className="font-medium">{t.name}</TD>
              <TD><span className="font-mono font-bold text-[#0D7377] text-xs">{t.code}</span></TD>
              <TD><Badge color="info">{t.device}</Badge></TD>
              <TD className="font-bold text-[#0D7377]">{fmt(t.price)}</TD>
              <TD><Badge color={t.timeVal==="فوري"?"success":"neutral"}>{t.timeVal}{t.timeUnit?" "+t.timeUnit:""}</Badge></TD>
              <TD className="text-[#999] text-xs">{t.instructions||"—"}</TD>
              <TD><div className="flex gap-1"><Btn small variant="ghost" onClick={()=>openEdit(t)}><Edit size={14}/></Btn><button onClick={()=>setDelConfirm(t)} className="p-1.5 rounded hover:bg-[#FFEBEE] text-[#D32F2F] transition-colors"><Trash2 size={14}/></button></div></TD>
            </TRow>
          ))}</tbody>
        </table>
        {filtered.length===0&&<EmptyState/>}
      </Card>
      <Modal open={addModal} onClose={()=>setAddModal(false)} title={editItem?`تعديل: ${editItem.name}`:"إضافة نوع صورة جديدة"}
        footer={<><Btn variant="secondary" onClick={handleSave} disabled={!form.name.trim()||!form.price}><Save size={16}/>حفظ</Btn><Btn variant="outline" onClick={()=>setAddModal(false)}>إلغاء</Btn></>}>
        <div className="space-y-4">
          <InputField label="نوع الصورة / التصوير" required placeholder="صورة صدر (X-Ray)" value={form.name} onChange={v=>setForm(p=>({...p,name:v}))}/>
          <InputField label="الرمز (Code)" placeholder="XR-CHEST" value={form.code} onChange={v=>setForm(p=>({...p,code:v}))}/>
          <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">الجهاز / الوسيلة <span className="text-[#D32F2F]">*</span></label><select value={form.device} onChange={e=>setForm(p=>({...p,device:e.target.value}))} className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}>{RAD_DEVICES.map(d=><option key={d}>{d}</option>)}</select></div>
          <InputField label="السعر (₪)" required type="number" placeholder="0" value={String(form.price)} onChange={v=>setForm(p=>({...p,price:parseFloat(v)||0}))}/>
          <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">وقت الإنجاز التقريبي</label><div className="flex gap-2"><input type="text" placeholder="مثال: 30" value={form.timeVal} onChange={e=>setForm(p=>({...p,timeVal:e.target.value}))} className="flex-1 h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/><select value={form.timeUnit} onChange={e=>setForm(p=>({...p,timeUnit:e.target.value}))} className="h-10 px-2 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}><option>دقيقة</option><option>ساعة</option><option>فوري</option></select></div></div>
          <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">تعليمات التحضير</label><textarea rows={2} value={form.instructions} onChange={e=>setForm(p=>({...p,instructions:e.target.value}))} placeholder='مثال: "يُمنع الأكل قبل ساعتين"' className="px-3 py-2 rounded-lg text-sm outline-none resize-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/></div>
          <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">ملاحظات</label><textarea rows={2} value={form.notes} onChange={e=>setForm(p=>({...p,notes:e.target.value}))} className="px-3 py-2 rounded-lg text-sm outline-none resize-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/></div>
        </div>
      </Modal>
      <Modal open={!!delConfirm} onClose={()=>setDelConfirm(null)} title="حذف صورة شعاعية"
        footer={<><Btn variant="danger" onClick={()=>{setImages(p=>p.filter(t=>t.id!==delConfirm?.id));setDelConfirm(null);toast("تم الحذف","warning")}}><Trash2 size={16}/>حذف</Btn><Btn variant="outline" onClick={()=>setDelConfirm(null)}>إلغاء</Btn></>}>
        <div className="text-center py-4"><div className="w-12 h-12 rounded-full bg-[#FFEBEE] flex items-center justify-center mx-auto mb-3"><AlertTriangle size={24} className="text-[#D32F2F]"/></div><p className="text-sm text-[#555]">هل تريد حذف <strong>"{delConfirm?.name}"</strong> من الدليل؟</p></div>
      </Modal>
    </div>
  );
}

// ─── FIN: ALL DRAWERS (overview + withdrawals) ────────────────────────────────

function FinAllDrawersScreen({drawers}:{drawers:Record<string,DrawerState>}){
  const [section,setSection]=useState<"overview"|"withdrawals">("overview");
  const totalBalance=Object.values(drawers).reduce((s,d)=>s+d.balance,0);
  const allTxs=Object.entries(drawers).flatMap(([dept,d])=>d.txs.filter(t=>t.type==="out").map(t=>({...t,deptName:DEPARTMENTS.find(x=>x.id===dept)?.short||dept})));
  return(
    <div className="space-y-5">
      <div className="flex gap-2">
        <button onClick={()=>setSection("overview")} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${section==="overview"?"bg-[#1B3A6B] text-white":"bg-white text-[#555] hover:bg-[#EBF3FB]"}`} style={{border:"1px solid #E0E0E0"}}>نظرة عامة — كل الجرارات</button>
        <button onClick={()=>setSection("withdrawals")} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${section==="withdrawals"?"bg-[#1B3A6B] text-white":"bg-white text-[#555] hover:bg-[#EBF3FB]"}`} style={{border:"1px solid #E0E0E0"}}>سحوبات الجرار</button>
      </div>
      {section==="overview"&&(
        <div className="space-y-5">
          <div className="p-4 rounded-2xl text-white font-bold text-center text-lg" style={{background:`linear-gradient(135deg,${C.primary},#0D4480)`}}>إجمالي النقد في جميع الجرارات: {fmt(totalBalance)}</div>
          <div className="grid grid-cols-4 gap-3">
            {DEPARTMENTS.map(d=>{
              const dr=drawers[d.id]; const todayIn=dr.txs.filter(t=>t.type==="in"&&t.time==="الآن"||t.time.includes("دقيقة")||t.time.includes("ساعة")).reduce((s,t)=>s+t.amount,0);
              return<div key={d.id} className="bg-white rounded-xl p-4 shadow-sm" style={{border:"1px solid #E0E0E0"}}><div className="flex items-center gap-2 mb-2"><d.Icon size={18} className="text-[#1B3A6B]"/><p className="text-sm font-semibold text-[#1B3A6B]">جرار {d.short}</p></div><p className="text-2xl font-bold text-[#1B3A6B]">{fmt(dr.balance)}</p><p className="text-xs text-[#388E3C] mt-1">+{fmt(dr.txs.filter(t=>t.auto&&t.type==="in").slice(0,2).reduce((s,t)=>s+t.amount,0))} اليوم</p></div>;
            })}
          </div>
          <Card title="رصيد كل جرار">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={drawersBars} margin={{top:5,right:0,left:-10,bottom:5}}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0"/>
                <XAxis dataKey="name" tick={{fontSize:11,fill:"#555"}}/><YAxis tick={{fontSize:10,fill:"#555"}}/>
                <Tooltip formatter={(v:number)=>fmt(v)}/>
                <Bar dataKey="رصيد" name="fin-bal" fill={C.secondary} radius={[4,4,0,0]}/>
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>
      )}
      {section==="withdrawals"&&(
        <Card title="سجل سحوبات الجرار — كل الأقسام"
          action={<div className="flex gap-2"><Btn small variant="ghost"><Download size={14}/>Excel</Btn><Btn small variant="ghost"><Printer size={14}/>PDF</Btn></div>}>
          <div className="flex gap-3 mb-4">
            <select className="h-9 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}><option value="">كل الأقسام</option>{DEPARTMENTS.map(d=><option key={d.id}>{d.short}</option>)}</select>
            <select className="h-9 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}><option value="">كل التصنيفات</option>{WITHDRAW_CATS.map(c=><option key={c.id}>{c.label}</option>)}</select>
          </div>
          {allTxs.length===0?<EmptyState msg="لا توجد سحوبات"/>:(
            <table className="w-full text-sm"><THead cols={["الوقت","القسم","العنوان","التصنيف","المستفيد","المبلغ"]}/>
              <tbody>{allTxs.map((tx,i)=><TRow key={`${tx.id}-${i}`} i={i}>
                <TD className="text-[#555] text-xs">{tx.time}</TD>
                <TD><Badge color="info">{(tx as any).deptName}</Badge></TD>
                <TD className="font-medium">{tx.title}</TD>
                <TD><Badge color="warning">{tx.category}</Badge></TD>
                <TD className="text-[#555]">{tx.beneficiary||"—"}</TD>
                <TD className="font-bold text-[#D32F2F]">-{fmt(tx.amount)}</TD>
              </TRow>)}</tbody>
            </table>
          )}
        </Card>
      )}
    </div>
  );
}

// ─── FINANCIAL SUMMARY ─────────────────────────────────────────────────────────

function FinancialSummaryScreen({drawers}:{drawers:Record<string,DrawerState>}){
  const totalBalance=Object.values(drawers).reduce((s,d)=>s+d.balance,0);
  const totalRevenue=127100; const totalWithdrawals=46100; const netProfit=totalRevenue-totalWithdrawals;
  return(
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 bg-white rounded-lg px-3 py-2 shadow-sm" style={{border:"1px solid #E0E0E0"}}><Filter size={15} className="text-[#555]"/><select className="text-sm bg-transparent outline-none"><option>يونيو 2026</option><option>مايو 2026</option><option>هذه السنة</option></select></div>
        <div className="flex gap-2"><Btn small variant="ghost"><Download size={14}/>Excel</Btn><Btn small variant="ghost"><Printer size={14}/>PDF</Btn></div>
      </div>
      <div className="rounded-2xl p-6 text-white" style={{background:`linear-gradient(135deg,#0D7377,#0a5c60)`}}>
        <p className="text-white/70 text-sm mb-1">صافي الربح</p><p className="text-5xl font-bold">{fmt(netProfit)}</p>
        <div className="flex gap-8 mt-4">
          <div><p className="text-white/60 text-xs">رصيد الجرارات الكلي</p><p className="text-xl font-bold">{fmt(totalBalance)}</p></div>
          <div><p className="text-white/60 text-xs">إجمالي الإيرادات</p><p className="text-xl font-bold">{fmt(totalRevenue)}</p></div>
          <div><p className="text-white/60 text-xs">إجمالي السحوبات</p><p className="text-xl font-bold">{fmt(totalWithdrawals)}</p></div>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {DEPARTMENTS.map(d=><KPICard key={d.id} title={`جرار ${d.short}`} value={fmt(drawers[d.id]?.balance||0)} Icon={Banknote} color="secondary"/>)}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Card title="الإيرادات حسب القسم">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={revenueByDept} margin={{top:5,right:0,left:-10,bottom:5}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0"/><XAxis dataKey="name" tick={{fontSize:11,fill:"#555"}}/><YAxis tick={{fontSize:10,fill:"#555"}}/>
              <Tooltip formatter={(v:number)=>fmt(v)}/>
              <Bar dataKey="إيرادات" name="fin-rev" fill={C.secondary} radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </Card>
        <Card title="تصنيف السحوبات">
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={withdrawCats} cx="50%" cy="50%" outerRadius={75} dataKey="value" nameKey="name">
                {withdrawCats.map((_,i)=><Cell key={`wc-${i}`} fill={PIE_COLORS[i]}/>)}
              </Pie>
              <Tooltip formatter={(v:number)=>fmt(v)}/><Legend wrapperStyle={{fontSize:10}}/>
            </PieChart>
          </ResponsiveContainer>
        </Card>
        <Card title="الاتجاه الشهري — إيرادات مقابل سحوبات" className="col-span-2">
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={monthlyTrend} margin={{top:5,right:0,left:-10,bottom:5}}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0"/><XAxis dataKey="month" tick={{fontSize:10,fill:"#555"}}/><YAxis tick={{fontSize:10,fill:"#555"}}/>
              <Tooltip formatter={(v:number)=>fmt(v)}/><Legend wrapperStyle={{fontSize:11}}/>
              <Line type="monotone" dataKey="إيرادات" name="fin-line-rev" stroke={C.secondary} strokeWidth={2.5} dot={{r:4}}/>
              <Line type="monotone" dataKey="سحوبات" name="fin-line-wd" stroke={C.danger} strokeWidth={2} dot={{r:3}} strokeDasharray="4 3"/>
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
}

// ─── DEBTS ─────────────────────────────────────────────────────────────────────

function DebtManagementScreen({debts,setDebts,drawers,doDeposit,toast}:{debts:DebtRow[];setDebts:React.Dispatch<React.SetStateAction<DebtRow[]>>;drawers:Record<string,DrawerState>;doDeposit:(dept:string,amount:number,title:string,type:string)=>void;toast:(m:string,t?:any)=>void}){
  const [search,setSearch]=useState(""); const [deptFilter,setDeptFilter]=useState(""); const [ageFilter,setAgeFilter]=useState<"all"|"<30"|"30-90"|">90">("all");
  const [smsModal,setSmsModal]=useState<DebtRow|null>(null); const [settleModal,setSettleModal]=useState<DebtRow|null>(null); const [settleAmount,setSettleAmount]=useState(""); const [sending,setSending]=useState(false); const [settling,setSettling]=useState(false);
  const filtered=debts.filter(d=>{if(search&&!d.patient.includes(search)&&!d.pid.includes(search))return false;if(deptFilter&&d.dept!==deptFilter)return false;if(ageFilter==="<30"&&d.days>=30)return false;if(ageFilter==="30-90"&&(d.days<30||d.days>90))return false;if(ageFilter===">90"&&d.days<=90)return false;return true;});
  const total=debts.reduce((s,d)=>s+d.amount,0); const under30=debts.filter(d=>d.days<30).reduce((s,d)=>s+d.amount,0); const mid=debts.filter(d=>d.days>=30&&d.days<=90).reduce((s,d)=>s+d.amount,0); const over90=debts.filter(d=>d.days>90).reduce((s,d)=>s+d.amount,0);
  const ageBadge=(days:number)=>days<30?<Badge color="success">&lt;30 يوم</Badge>:days<=90?<Badge color="warning">30–90 يوم</Badge>:<Badge color="danger">&gt;90 يوم</Badge>;
  const sendSMS=()=>{setSending(true);setTimeout(()=>{setDebts(p=>p.map(d=>d.id===smsModal?.id?{...d,smsSent:true}:d));setSending(false);setSmsModal(null);toast(`تم إرسال SMS لـ ${smsModal?.patient}`)},800)};
  const handleSettle=()=>{
    if(!settleModal||!settleAmount)return;const paid=parseFloat(settleAmount);
    const deptMap:Record<string,string>={الجراحة:"surgery",المختبر:"lab",الأشعة:"radiology",التأهيلي:"rehab"};
    setSettling(true);
    setTimeout(()=>{doDeposit(deptMap[settleModal.dept]||"surgery",paid,`تسديد دين — ${settleModal.patient}`,"سند قبض — دفعة نقدية");setDebts(p=>p.map(d=>{if(d.id!==settleModal.id)return d;const n=d.amount-paid;return n<=0?null:{...d,amount:n};}).filter(Boolean) as DebtRow[]);setSettling(false);setSettleModal(null);setSettleAmount("");toast(`تم تسجيل دفعة ${fmt(paid)} من ${settleModal.patient}`)},700);
  };
  return(
    <div className="space-y-5">
      <div className="grid grid-cols-4 gap-4">
        <KPICard title="إجمالي الديون" value={fmt(total)} Icon={AlertTriangle} color="danger"/>
        <KPICard title="أقل من 30 يوم" value={fmt(under30)} Icon={CheckCircle} color="success"/>
        <KPICard title="30–90 يوم" value={fmt(mid)} Icon={Clock} color="warning"/>
        <KPICard title="أكثر من 90 يوم" value={fmt(over90)} Icon={XCircle} color="danger"/>
      </div>
      <Card title="تفاصيل ديون المرضى" action={<div className="flex gap-2"><Btn small variant="ghost"><Download size={14}/>Excel</Btn><Btn small variant="ghost"><Printer size={14}/>PDF</Btn></div>}>
        <div className="flex gap-3 mb-4">
          <div className="relative flex-1"><Search size={15} className="absolute top-1/2 right-3 -translate-y-1/2 text-[#999]"/><input type="text" placeholder="بحث..." value={search} onChange={e=>setSearch(e.target.value)} className="w-full h-9 pr-9 pl-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/></div>
          <select value={deptFilter} onChange={e=>setDeptFilter(e.target.value)} className="h-9 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}><option value="">كل الأقسام</option>{DEPARTMENTS.map(d=><option key={d.id} value={d.short}>{d.short}</option>)}</select>
          {(["all","<30","30-90",">90"] as const).map(v=><button key={v} onClick={()=>setAgeFilter(v)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${ageFilter===v?"bg-[#1B3A6B] text-white":"bg-white text-[#555] hover:bg-[#EBF3FB]"}`} style={{border:"1px solid #E0E0E0"}}>{v==="all"?"الكل":v}</button>)}
        </div>
        {filtered.length===0?<EmptyState msg="لا توجد ديون بهذه الفلاتر"/>:(
          <table className="w-full text-sm"><THead cols={["اسم المريض","رقم الهوية","القسم","المبلغ","تاريخ الدين","مدة التأخير","الهاتف",""]}/>
            <tbody>{filtered.map((d,i)=><TRow key={d.id} i={i}>
              <TD className="font-medium">{d.patient}</TD><TD className="text-[#555] font-mono">{d.pid}</TD><TD><Badge color="info">{d.dept}</Badge></TD>
              <TD className="font-bold text-[#D32F2F]">{fmt(d.amount)}</TD><TD className="text-[#555]">{d.date}</TD><TD>{ageBadge(d.days)}</TD><TD className="text-[#555] font-mono text-xs">{d.phone}</TD>
              <TD><div className="flex gap-1"><Btn small variant="secondary" onClick={()=>setSmsModal(d)}>{d.smsSent?<span className="text-[10px]">أُرسل</span>:<MessageSquare size={12}/>}</Btn><Btn small variant="outline" onClick={()=>setSettleModal(d)}>تسديد</Btn></div></TD>
            </TRow>)}</tbody>
          </table>
        )}
      </Card>
      <Modal open={!!smsModal} onClose={()=>setSmsModal(null)} title="إرسال رسالة تذكير SMS"
        footer={<><Btn variant="secondary" loading={sending} onClick={sendSMS}><MessageSquare size={16}/>إرسال الرسالة</Btn><Btn variant="outline" onClick={()=>setSmsModal(null)}>إلغاء</Btn></>}>
        {smsModal&&<div className="space-y-4"><div className="p-3 rounded-xl bg-[#E3F2FD]"><p className="text-sm">المريض: <strong>{smsModal.patient}</strong></p><p className="text-sm mt-0.5">الهاتف: <strong className="font-mono">{smsModal.phone}</strong></p></div><div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">نص الرسالة</label><textarea rows={4} defaultValue={`عزيزي/عزيزتي ${smsModal.patient}، يرجى التكرم بتسديد دينك المستحق بقيمة ${fmt(smsModal.amount)}. للاستفسار اتصل بالمركز. شكراً`} className="px-3 py-2 rounded-lg text-sm outline-none resize-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/><p className="text-xs text-[#999] text-left">120/160 حرف</p></div></div>}
      </Modal>
      <Modal open={!!settleModal} onClose={()=>setSettleModal(null)} title="تسديد دين مريض"
        footer={<><Btn variant="success" loading={settling} onClick={handleSettle}><Check size={16}/>تأكيد التسديد</Btn><Btn variant="outline" onClick={()=>setSettleModal(null)}>إلغاء</Btn></>}>
        {settleModal&&<div className="space-y-4"><div className="p-3 rounded-xl bg-[#FFEBEE]"><p className="text-sm">المريض: <strong>{settleModal.patient}</strong></p><p className="text-sm mt-1">إجمالي الدين: <strong className="text-[#D32F2F] text-lg">{fmt(settleModal.amount)}</strong></p></div><InputField label="المبلغ المُسدَّد (₪)" required type="number" placeholder="0" value={settleAmount} onChange={setSettleAmount}/>{settleAmount&&parseFloat(settleAmount)>0&&<p className={`text-xs p-2 rounded ${parseFloat(settleAmount)>=settleModal.amount?"bg-[#E8F5E9] text-[#388E3C]":"bg-[#FFF8E1] text-[#FF8F00]"}`}>{parseFloat(settleAmount)>=settleModal.amount?"✓ ستُسدَّد الديون بالكامل":`دين متبقٍ: ${fmt(settleModal.amount-parseFloat(settleAmount))}`}</p>}<p className="text-xs text-[#999]">سيُضاف للجرار تلقائياً</p></div>}
      </Modal>
    </div>
  );
}

// ─── PAYROLL ───────────────────────────────────────────────────────────────────

function PayrollScreen({employees,setEmployees,drawers,doWithdraw,toast}:{employees:Employee[];setEmployees:React.Dispatch<React.SetStateAction<Employee[]>>;drawers:Record<string,DrawerState>;doWithdraw:(dept:string,amount:number,title:string,cat:string,ben?:string)=>void;toast:(m:string,t?:any)=>void}){
  const [confirmModal,setConfirmModal]=useState<Employee|null>(null); const [paying,setPaying]=useState(false);
  const calcNet=(e:Employee)=>e.salary-e.expenses; const totalSalaries=employees.reduce((s,e)=>s+e.salary,0);
  const handlePay=()=>{
    if(!confirmModal)return;
    const deptDrawer=drawers[confirmModal.dept];
    if(!deptDrawer||deptDrawer.balance<calcNet(confirmModal)){toast("⚠️ رصيد الجرار غير كافٍ","warning");return;}
    setPaying(true);
    setTimeout(()=>{doWithdraw(confirmModal.dept,calcNet(confirmModal),`راتب ${confirmModal.name} — يونيو 2026`,"راتب موظف",confirmModal.name);setEmployees(p=>p.map(e=>e.id===confirmModal.id?{...e,status:"paid" as const,paidDate:"29/06/2026"}:e));setPaying(false);setConfirmModal(null);toast(`تم صرف راتب ${confirmModal.name} ✓ — خُصم من جرار القسم`)},700);
  };
  const statusBadge=(s:string)=>s==="paid"?<Badge color="success">مصروف</Badge>:s==="calculated"?<Badge color="warning">مُحتسب</Badge>:<Badge color="neutral">لم يُحتسب</Badge>;
  return(
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-4">
        <KPICard title="إجمالي رواتب الشهر" value={fmt(totalSalaries)} Icon={Users} color="secondary"/>
        <KPICard title="إجمالي الخصومات" value={fmt(employees.reduce((s,e)=>s+e.expenses,0))} Icon={Receipt} color="warning"/>
        <KPICard title="إجمالي الصافي المستحق" value={fmt(employees.reduce((s,e)=>s+calcNet(e),0))} Icon={DollarSign} color="primary"/>
      </div>
      <Card title="رواتب موظفي يونيو 2026">
        <table className="w-full text-sm"><THead cols={["الموظف","القسم","الراتب الأساسي","الخصومات","الراتب الصافي","الحالة",""]}/>
          <tbody>{employees.map((e,i)=>{
            const dept=DEPARTMENTS.find(d=>d.id===e.dept); const insuf=drawers[e.dept]&&drawers[e.dept].balance<calcNet(e);
            return<TRow key={e.id} i={i}><TD className="font-medium">{e.name}</TD><TD><Badge color="info">{dept?.short||e.dept}</Badge></TD><TD className="font-semibold">{fmt(e.salary)}</TD><TD className="text-[#FF8F00] font-medium">{fmt(e.expenses)}</TD><TD className="font-bold text-[#0D7377]">{e.status!=="pending"?fmt(calcNet(e)):<span className="text-[#999]">—</span>}</TD><TD>{statusBadge(e.status)}{e.paidDate&&<span className="text-xs text-[#999] mr-1">{e.paidDate}</span>}</TD>
              <TD>{e.status==="pending"&&<Btn small variant="outline" onClick={()=>setEmployees(p=>p.map(x=>x.id===e.id?{...x,status:"calculated" as const}:x))}>احتساب</Btn>}{e.status==="calculated"&&<Btn small variant="success" onClick={()=>setConfirmModal(e)}>{insuf?"⚠️ رصيد ناقص":"صرف الراتب"}</Btn>}</TD>
            </TRow>;
          })}</tbody>
        </table>
      </Card>
      <Modal open={!!confirmModal} onClose={()=>setConfirmModal(null)} title="تأكيد صرف الراتب"
        footer={<><Btn variant="success" loading={paying} onClick={handlePay}><Check size={16}/>تأكيد الصرف</Btn><Btn variant="outline" onClick={()=>setConfirmModal(null)}>إلغاء</Btn></>}>
        {confirmModal&&<div className="space-y-3"><div className="p-4 rounded-xl bg-[#E8F5E9] text-center"><Wallet size={32} className="mx-auto text-[#388E3C] mb-2"/><p className="text-base font-bold">{confirmModal.name}</p><p className="text-2xl font-bold mt-2">{fmt(calcNet(confirmModal))}</p><p className="text-xs text-[#555] mt-1">لشهر يونيو 2026</p></div><div className="p-3 rounded-lg bg-[#EBF3FB] text-sm"><p>سيُخصم من جرار قسم: <strong>{DEPARTMENTS.find(d=>d.id===confirmModal.dept)?.short}</strong></p><p className="mt-1">رصيد الجرار الحالي: <strong className="text-[#0D7377]">{fmt(drawers[confirmModal.dept]?.balance||0)}</strong></p>{drawers[confirmModal.dept]?.balance<calcNet(confirmModal)&&<p className="text-[#D32F2F] text-xs mt-1">⚠️ رصيد الجرار غير كافٍ!</p>}</div></div>}
      </Modal>
    </div>
  );
}

// ─── INVENTORY ─────────────────────────────────────────────────────────────────

function InventoryScreen({toast}:{toast:(m:string,t?:any)=>void}){
  const [inv,setInv]=useState(initialInventory); const [addQtyModal,setAddQtyModal]=useState<typeof initialInventory[0]|null>(null); const [addAmount,setAddAmount]=useState("");
  const statusBadge=(s:string)=>s==="ok"?<Badge color="success"><Package size={10}/>كافٍ</Badge>:s==="low"?<Badge color="warning"><AlertCircle size={10}/>منخفض</Badge>:s==="critical"?<Badge color="danger"><AlertCircle size={10}/>حرج</Badge>:<Badge color="danger"><XCircle size={10}/>نفد</Badge>;
  return(
    <div className="space-y-5">
      {inv.filter(i=>i.status!=="ok").map(item=><div key={item.id} className="flex items-center gap-3 px-4 py-3 rounded-xl" style={{backgroundColor:"#FFF8E1",border:"1px solid #FFE082"}}><AlertTriangle size={16} className="text-[#FF8F00]"/><span className="text-sm text-[#E65100]">تحذير: مخزون <strong>{item.name}</strong> {item.qty===0?"نفد":"منخفض"} — الكمية الحالية: <strong>{item.qty}</strong></span></div>)}
      <Card title="إدارة المخزون والكيتات" action={<Btn small variant="secondary"><Plus size={14}/>إضافة Kit</Btn>}>
        <table className="w-full text-sm"><THead cols={["اسم الكيت","الفحوصات المرتبطة","الكمية","حد التنبيه","الحالة",""]}/>
          <tbody>{inv.map((item,i)=><TRow key={item.id} i={i}><TD className="font-bold text-[#1B3A6B]">{item.name}</TD><TD><div className="flex gap-1 flex-wrap">{item.tests.map(t=><Badge key={t} color="info">{t}</Badge>)}</div></TD><TD><span className={`text-xl font-bold ${item.qty===0?"text-[#D32F2F]":item.qty<=item.threshold?"text-[#FF8F00]":"text-[#388E3C]"}`}>{item.qty}</span></TD><TD className="text-[#555]">{item.threshold}</TD><TD>{statusBadge(item.status)}</TD><TD><Btn small variant="outline" onClick={()=>setAddQtyModal(item)}><Plus size={12}/>إضافة كمية</Btn></TD></TRow>)}</tbody>
        </table>
      </Card>
      <Modal open={!!addQtyModal} onClose={()=>setAddQtyModal(null)} title="إضافة كمية للمخزون"
        footer={<><Btn variant="secondary" onClick={()=>{if(!addQtyModal||!addAmount)return;const qty=parseInt(addAmount)||0;setInv(p=>p.map(i=>i.id===addQtyModal.id?{...i,qty:i.qty+qty,status:(i.qty+qty>=i.threshold?"ok":i.qty+qty>0?"low":"empty") as "ok"|"low"|"critical"|"empty"}:i));setAddQtyModal(null);setAddAmount("");toast(`تم إضافة ${qty} وحدة لـ ${addQtyModal.name}`,"success")}}><Save size={16}/>تأكيد الإضافة</Btn><Btn variant="outline" onClick={()=>setAddQtyModal(null)}>إلغاء</Btn></>}>
        {addQtyModal&&<div className="space-y-4"><div className="p-3 rounded-xl bg-[#EBF3FB]"><p className="text-sm">الكمية الحالية لـ <strong>{addQtyModal.name}</strong>: <span className="text-xl font-bold text-[#1B3A6B]">{addQtyModal.qty}</span></p></div><InputField label="الكمية المُضافة" required type="number" placeholder="0" value={addAmount} onChange={setAddAmount}/>{addAmount&&parseInt(addAmount)>0&&<p className="text-xs text-[#388E3C]">الكمية بعد الإضافة: <strong>{addQtyModal.qty+parseInt(addAmount)}</strong></p>}</div>}
      </Modal>
    </div>
  );
}

// ─── BACKUP ────────────────────────────────────────────────────────────────────

function BackupScreen({toast}:{toast:(m:string,t?:any)=>void}){
  const [progress,setProgress]=useState<Record<string,number>>({});const [done,setDone]=useState<Record<string,boolean>>({});const [failed,setFailed]=useState<Record<string,boolean>>({});
  const run=(id:string,label:string)=>{setProgress(p=>({...p,[id]:0}));setDone(p=>({...p,[id]:false}));setFailed(p=>({...p,[id]:false}));let pct=0;const iv=setInterval(()=>{pct+=15;setProgress(p=>({...p,[id]:Math.min(pct,100)}));if(pct>=100){clearInterval(iv);const s=Math.random()>0.15;if(s){setDone(p=>({...p,[id]:true}));toast(`تم الرفع بنجاح لـ ${label} ✓`);}else{setFailed(p=>({...p,[id]:true}));toast(`فشل الرفع لـ ${label}`,"error");}}},200)};
  const opts=[{id:"drive1",label:"Google Drive 1",Icon:CloudUpload,last:"29/06/2026 03:00"},{id:"drive2",label:"Google Drive 2",Icon:CloudUpload,last:"29/06/2026 03:01"},{id:"drive3",label:"Google Drive 3",Icon:CloudUpload,last:"29/06/2026 03:02"},{id:"hosting",label:"سيرفر الاستضافة",Icon:Database,last:"29/06/2026 03:03"},{id:"device",label:"تصدير ZIP على الجهاز",Icon:Download,last:"—"}];
  return(
    <div className="max-w-2xl mx-auto space-y-5">
      <div className="p-5 rounded-2xl" style={{backgroundColor:"#E8F5E9",border:"1px solid #A5D6A7"}}><div className="flex items-center gap-3"><div className="w-10 h-10 rounded-full bg-[#388E3C] flex items-center justify-center"><CheckCircle size={20} className="text-white"/></div><div><p className="text-sm font-bold text-[#388E3C]">النسخ الاحتياطي التلقائي — نشط ✓</p><p className="text-xs text-[#555]">يعمل يومياً الساعة 03:00 صباحاً على 4 وجهات</p><p className="text-xs text-[#388E3C] mt-0.5">آخر نسخة: اليوم 29/06/2026 الساعة 03:03</p></div></div></div>
      <Card title="النسخ الاحتياطي اليدوي">
        <div className="space-y-4">{opts.map(opt=>(
          <div key={opt.id} className="p-4 rounded-xl space-y-2" style={{backgroundColor:"#FAFAFA",border:"1px solid #E0E0E0"}}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-full bg-[#EBF3FB] flex items-center justify-center"><opt.Icon size={20} className="text-[#1B3A6B]"/></div><div><p className="text-sm font-medium">{opt.label}</p><p className="text-xs text-[#999]">آخر نسخة: {done[opt.id]?"الآن":opt.last}</p></div></div>
              <div className="flex items-center gap-2">
                {done[opt.id]&&!failed[opt.id]&&<Badge color="success"><Check size={10}/>ناجحة</Badge>}
                {failed[opt.id]&&<Badge color="danger">فشلت</Badge>}
                <Btn small variant={failed[opt.id]?"danger":"secondary"} disabled={progress[opt.id]!==undefined&&progress[opt.id]<100&&!done[opt.id]&&!failed[opt.id]} onClick={()=>run(opt.id,opt.label)}>
                  {progress[opt.id]!==undefined&&progress[opt.id]<100&&!done[opt.id]&&!failed[opt.id]?<span className="flex items-center gap-1"><RefreshCw size={12} className="animate-spin"/>جارٍ...</span>:failed[opt.id]?"إعادة المحاولة":"نسخ الآن"}
                </Btn>
              </div>
            </div>
            {progress[opt.id]!==undefined&&progress[opt.id]<100&&!done[opt.id]&&!failed[opt.id]&&<div className="w-full h-1.5 bg-[#E0E0E0] rounded-full overflow-hidden"><div className="h-full bg-[#0D7377] rounded-full transition-all" style={{width:`${progress[opt.id]}%`}}/></div>}
          </div>
        ))}</div>
      </Card>
    </div>
  );
}

// ─── PRINT SETTINGS ────────────────────────────────────────────────────────────

function PrintSettingsScreen({toast}:{toast:(m:string,t?:any)=>void}){
  const [margins,setMargins]=useState({top:25,right:15,bottom:20,left:15});
  const [paperSize,setPaperSize]=useState("A4"); const [orientation,setOrientation]=useState("portrait");
  const [customEnabled,setCustomEnabled]=useState(false);
  const [customMargins,setCustomMargins]=useState({lab:{top:30,right:15,bottom:25,left:15},invoice:{top:25,right:15,bottom:25,left:15},statement:{top:25,right:15,bottom:25,left:15},radiology:{top:25,right:15,bottom:25,left:15},financial:{top:25,right:15,bottom:25,left:15}});
  const [previewModal,setPreviewModal]=useState("");
  const setM=(k:keyof typeof margins,v:string)=>setMargins(p=>({...p,[k]:parseInt(v)||0}));
  const A4_W=210; const A4_H=297; const SCALE=0.7;
  const previewStyle={width:A4_W*SCALE,height:A4_H*SCALE,position:"relative" as const,backgroundColor:"white",border:"1px solid #CCC",margin:"0 auto",overflow:"hidden"};
  const topH=`${(margins.top/A4_H)*100}%`; const botH=`${(margins.bottom/A4_H)*100}%`;
  const printTypes=[{k:"lab",l:"نتائج المختبر"},{k:"invoice",l:"الفواتير والإيصالات"},{k:"statement",l:"كشوفات الحسابات"},{k:"radiology",l:"تقرير الأشعة"},{k:"financial",l:"تقرير مالي"}];
  return(
    <div className="space-y-6">
      <div><h2 className="text-lg font-bold text-[#1B3A6B]">إعدادات الطباعة</h2><p className="text-sm text-[#555] mt-1">حدد الهوامش لكل نوع مطبوعة حتى لا يتداخل الطباعة مع ترويسة الورق</p></div>
      <div className="p-4 rounded-xl bg-[#E3F2FD]" style={{border:"1px solid #BBDEFB"}}><p className="text-sm text-[#1565C0]">ℹ️ المركز يطبع على ورق مطبوع مسبقاً بترويسة رأسية وتذييل. قم بتحديد هوامش كافية لكل نوع من المطبوعات لتجنب الطباعة فوق الترويسة الموجودة.</p></div>
      <div className="grid grid-cols-2 gap-6">
        {/* Margin Controls */}
        <Card title="الهوامش الافتراضية (لجميع المطبوعات)">
          <div className="space-y-4">
            <div className="flex flex-col items-center gap-3">
              <div className="flex flex-col items-center gap-1 w-full max-w-xs">
                <div className="flex items-center gap-2"><label className="text-xs font-semibold text-[#555] w-28">الهامش العلوي (mm)</label><input type="number" value={margins.top} onChange={e=>setM("top",e.target.value)} className="w-20 h-8 px-2 rounded text-sm text-center outline-none" style={{border:"1px solid #CCC"}}/></div>
                <div className="flex items-center gap-2 my-1">
                  <div className="flex items-center gap-2"><label className="text-xs font-semibold text-[#555] w-28">الهامش الأيمن (mm)</label><input type="number" value={margins.right} onChange={e=>setM("right",e.target.value)} className="w-20 h-8 px-2 rounded text-sm text-center outline-none" style={{border:"1px solid #CCC"}}/></div>
                </div>
                <div className="flex items-center gap-2"><label className="text-xs font-semibold text-[#555] w-28">الهامش الأيسر (mm)</label><input type="number" value={margins.left} onChange={e=>setM("left",e.target.value)} className="w-20 h-8 px-2 rounded text-sm text-center outline-none" style={{border:"1px solid #CCC"}}/></div>
                <div className="flex items-center gap-2 mt-1"><label className="text-xs font-semibold text-[#555] w-28">الهامش السفلي (mm)</label><input type="number" value={margins.bottom} onChange={e=>setM("bottom",e.target.value)} className="w-20 h-8 px-2 rounded text-sm text-center outline-none" style={{border:"1px solid #CCC"}}/></div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">حجم الورق</label><select value={paperSize} onChange={e=>setPaperSize(e.target.value)} className="h-9 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}><option>A4</option><option>A5</option><option>Letter</option></select></div>
              <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">الاتجاه</label><div className="flex gap-2">{[["portrait","عمودي"],["landscape","أفقي"]].map(([v,l])=><button key={v} onClick={()=>setOrientation(v)} className={`flex-1 h-9 rounded-lg text-xs font-medium transition-colors ${orientation===v?"bg-[#1B3A6B] text-white":"bg-white text-[#555]"}`} style={{border:"1px solid #E0E0E0"}}>{l}</button>)}</div></div>
            </div>
          </div>
        </Card>
        {/* A4 Live Preview */}
        <Card title="معاينة الصفحة">
          <div className="flex flex-col items-center">
            <div style={previewStyle}>
              <div style={{position:"absolute",top:0,left:0,right:0,height:topH,backgroundColor:"#E0E0E0",display:"flex",alignItems:"center",justifyContent:"center",borderBottom:"1px dashed #999"}}>
                <span style={{fontSize:8,color:"#999"}}>منطقة الترويسة — {margins.top}mm</span>
              </div>
              <div style={{position:"absolute",bottom:0,left:0,right:0,height:botH,backgroundColor:"#E0E0E0",display:"flex",alignItems:"center",justifyContent:"center",borderTop:"1px dashed #999"}}>
                <span style={{fontSize:8,color:"#999"}}>منطقة التذييل — {margins.bottom}mm</span>
              </div>
              <div style={{position:"absolute",top:topH,bottom:botH,left:`${(margins.left/A4_W)*100}%`,right:`${(margins.right/A4_W)*100}%`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                <p style={{fontSize:8,color:"#1B3A6B",textAlign:"center",fontWeight:600}}>منطقة الطباعة الآمنة</p>
              </div>
            </div>
            <div className="flex gap-6 mt-3 text-xs text-[#555]">
              <span>↕ علوي: {margins.top}mm</span><span>↕ سفلي: {margins.bottom}mm</span>
            </div>
            <div className="flex gap-6 text-xs text-[#555]"><span>↔ أيمن: {margins.right}mm</span><span>↔ أيسر: {margins.left}mm</span></div>
          </div>
        </Card>
      </div>
      {/* Custom per-doc margins */}
      <Card title="هوامش مخصصة لكل نوع مطبوعة" action={<div className="flex items-center gap-3"><span className="text-xs text-[#555]">تفعيل هوامش مخصصة</span><button onClick={()=>setCustomEnabled(!customEnabled)} className={`w-11 h-6 rounded-full transition-colors relative ${customEnabled?"bg-[#388E3C]":"bg-[#CCC]"}`}><span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${customEnabled?"right-0.5":"left-0.5"}`}/></button></div>}>
        {!customEnabled?<p className="text-sm text-[#999] py-4 text-center">فعّل الخيار أعلاه لتحديد هوامش مختلفة لكل نوع مطبوعة</p>:(
          <div className="space-y-3">
            {printTypes.map(pt=>(
              <div key={pt.k} className="p-4 rounded-xl" style={{backgroundColor:"#FAFAFA",border:"1px solid #E0E0E0"}}>
                <div className="flex items-center justify-between mb-3"><p className="text-sm font-semibold text-[#1B3A6B]">{pt.l}</p><Btn small variant="ghost" onClick={()=>setPreviewModal(pt.l)}><Eye size={14}/>معاينة الطباعة</Btn></div>
                <div className="grid grid-cols-4 gap-3">
                  {(["top","right","bottom","left"] as const).map(side=>(<div key={side} className="flex flex-col gap-1"><label className="text-[10px] font-semibold text-[#999]">{{top:"العلوي",right:"الأيمن",bottom:"السفلي",left:"الأيسر"}[side]} (mm)</label><input type="number" value={(customMargins as any)[pt.k][side]} onChange={e=>setCustomMargins(p=>({...p,[pt.k]:{...(p as any)[pt.k],[side]:parseInt(e.target.value)||0}}))} className="h-8 px-2 rounded text-xs text-center outline-none" style={{border:"1px solid #CCC"}}/></div>))}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
      {/* Save button */}
      <div className="sticky bottom-0 bg-[#F5F5F5] pt-3 pb-4">
        <Btn variant="primary" full onClick={()=>toast("تم حفظ إعدادات الطباعة ✓ — ستُطبَّق على جميع المطبوعات","success")}><Save size={16}/>حفظ إعدادات الطباعة</Btn>
      </div>
      {/* Print preview modal */}
      <Modal open={!!previewModal} onClose={()=>setPreviewModal("")} title={`معاينة طباعة — ${previewModal}`}
        footer={<><Btn variant="outline"><Printer size={16}/>طباعة صفحة اختبار</Btn><Btn variant="outline" onClick={()=>setPreviewModal("")}>إغلاق</Btn></>}>
        <div className="flex flex-col items-center py-4">
          <div style={{width:160,height:226,border:"1px solid #CCC",position:"relative",backgroundColor:"white"}}>
            <div style={{position:"absolute",top:0,left:0,right:0,height:"12%",backgroundColor:"#E8E8E8",borderBottom:"1px dashed #999",display:"flex",alignItems:"center",justifyContent:"center"}}><span style={{fontSize:7,color:"#777"}}>ترويسة المركز</span></div>
            <div style={{position:"absolute",bottom:0,left:0,right:0,height:"9%",backgroundColor:"#E8E8E8",borderTop:"1px dashed #999",display:"flex",alignItems:"center",justifyContent:"center"}}><span style={{fontSize:7,color:"#777"}}>تذييل المركز</span></div>
            <div style={{position:"absolute",top:"12%",bottom:"9%",left:"8%",right:"8%",padding:6}}><div className="space-y-1">{[1,2,3,4].map(i=><div key={i} className="h-1.5 bg-[#E0E0E0] rounded" style={{width:`${60+i*8}%`}}/>)}</div></div>
          </div>
          <p className="text-xs text-[#999] mt-2">المناطق الرمادية = ترويسة وتذييل الورق المطبوع مسبقاً</p>
        </div>
      </Modal>
    </div>
  );
}

// ─── REPORTS ───────────────────────────────────────────────────────────────────

function ReportsScreen({toast}:{toast:(m:string,t?:any)=>void}){
  const [repType,setRepType]=useState("patients"); const [fields,setFields]=useState(["الاسم","رقم الهوية","القسم","المبلغ","الدين"]);
  const allFields=["الاسم","رقم الهوية","القسم","الجوال","المبلغ","المدفوع","الدين","التاريخ","التشخيص","التأمين"];
  const toggle=(f:string)=>setFields(p=>p.includes(f)?p.filter(x=>x!==f):[...p,f]);
  const TABS=[{k:"patients",l:"كشوف المرضى"},{k:"companies",l:"كشوف الشركات"},{k:"insurance",l:"شركات التأمين"},{k:"depts",l:"كشوف الأقسام"},{k:"custom",l:"تقرير مخصص"}];
  return(
    <div className="space-y-5">
      <div className="flex gap-2 flex-wrap">{TABS.map(t=><button key={t.k} onClick={()=>setRepType(t.k)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${repType===t.k?"bg-[#1B3A6B] text-white":"bg-white text-[#555] hover:bg-[#EBF3FB]"}`} style={{border:"1px solid #E0E0E0"}}>{t.l}</button>)}</div>
      <Card title="فلاتر التقرير"><div className="grid grid-cols-3 gap-4"><div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">من تاريخ</label><input type="date" defaultValue="2026-06-01" className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/></div><div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-[#555]">إلى تاريخ</label><input type="date" defaultValue="2026-06-29" className="h-10 px-3 rounded-lg text-sm outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}/></div></div>
        {repType==="custom"&&<div className="mt-4"><div className="flex items-center justify-between mb-2"><label className="text-xs font-semibold text-[#555]">اختر الحقول</label><div className="flex gap-2"><button onClick={()=>setFields([...allFields])} className="text-xs text-[#0D7377] hover:underline">تحديد الكل</button><button onClick={()=>setFields([])} className="text-xs text-[#D32F2F] hover:underline">إلغاء الكل</button></div></div><div className="grid grid-cols-4 gap-2">{allFields.map(f=><label key={f} className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-colors ${fields.includes(f)?"bg-[#E6F4F4]":"bg-[#FAFAFA]"}`} style={{border:"1px solid #E0E0E0"}}><input type="checkbox" checked={fields.includes(f)} onChange={()=>toggle(f)} className="accent-[#0D7377]"/><span className="text-xs">{f}</span></label>)}</div></div>}
      </Card>
      <Card title={`معاينة — عرض ${mockPatients.length} نتائج`}
        action={<div className="flex gap-2"><Btn small variant="ghost" onClick={()=>toast("جارٍ تحميل Excel...","info")}><Download size={14}/>Excel</Btn><Btn small variant="ghost" onClick={()=>toast("جارٍ تحضير PDF...","info")}><Printer size={14}/>PDF</Btn></div>}>
        <table className="w-full text-sm"><THead cols={fields.length?fields:["الاسم","القسم","الدين"]}/>
          <tbody>{mockPatients.map((p,i)=><TRow key={p.id} i={i}>
            {fields.includes("الاسم")&&<TD className="font-medium">{p.name}</TD>}
            {fields.includes("رقم الهوية")&&<TD className="font-mono text-[#555]">{p.id}</TD>}
            {fields.includes("القسم")&&<TD><Badge color="info">{DEPARTMENTS.find(d=>d.id===p.dept)?.short||p.dept}</Badge></TD>}
            {fields.includes("الجوال")&&<TD className="text-[#555]">{p.phone}</TD>}
            {fields.includes("الدين")&&<TD className={p.debt>0?"text-[#D32F2F] font-bold":"text-[#388E3C]"}>{p.debt>0?fmt(p.debt):"مسدد"}</TD>}
            {!fields.length&&<><TD className="font-medium">{p.name}</TD><TD><Badge color="info">{DEPARTMENTS.find(d=>d.id===p.dept)?.short||p.dept}</Badge></TD><TD>{p.debt>0?<span className="text-[#D32F2F] font-bold">{fmt(p.debt)}</span>:"—"}</TD></>}
          </TRow>)}</tbody>
        </table>
      </Card>
    </div>
  );
}

// ─── GENERAL SETTINGS ──────────────────────────────────────────────────────────

function GeneralSettingsScreen({toast}:{toast:(m:string,t?:any)=>void}){
  const [tab,setTab]=useState("employees"); const [employees,setEmployees]=useState(initialEmployees);
  const TABS=[{k:"employees",l:"الموظفون"},{k:"insurance",l:"شركات التأمين"},{k:"suppliers",l:"شركات الموردين"},{k:"sms",l:"إعدادات SMS"}];
  return(
    <div className="space-y-5">
      <div className="flex gap-2">{TABS.map(t=><button key={t.k} onClick={()=>setTab(t.k)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${tab===t.k?"bg-[#1B3A6B] text-white":"bg-white text-[#555] hover:bg-[#EBF3FB]"}`} style={{border:"1px solid #E0E0E0"}}>{t.l}</button>)}</div>
      {tab==="employees"&&<Card title="إدارة الموظفين" action={<Btn small variant="secondary"><Plus size={14}/>موظف جديد</Btn>}><table className="w-full text-sm"><THead cols={["الاسم","القسم","الدور","الراتب الأساسي",""]}/><tbody>{employees.map((e,i)=><TRow key={e.id} i={i}><TD className="font-medium">{e.name}</TD><TD><Badge color="info">{DEPARTMENTS.find(d=>d.id===e.dept)?.short||e.dept}</Badge></TD><TD className="text-[#555]">{e.role}</TD><TD className="font-bold text-[#0D7377]">{fmt(e.salary)}</TD><TD><div className="flex gap-1"><Btn small variant="ghost"><Edit size={14}/></Btn><Btn small variant="ghost"><Trash2 size={14}/></Btn></div></TD></TRow>)}</tbody></table></Card>}
      {tab==="insurance"&&<Card title="شركات التأمين" action={<Btn small variant="secondary"><Plus size={14}/>إضافة</Btn>}><table className="w-full text-sm"><THead cols={["اسم الشركة","رقم التواصل",""]}/><tbody>{["التأمين الوطني","شركة الأمان للتأمين","التأمين الصحي المتحد"].map((c,i)=><TRow key={c} i={i}><TD className="font-medium">{c}</TD><TD className="text-[#555]">+970 2 XXX XXXX</TD><TD><div className="flex gap-1"><Btn small variant="ghost"><Edit size={14}/></Btn><Btn small variant="ghost"><Trash2 size={14}/></Btn></div></TD></TRow>)}</tbody></table></Card>}
      {tab==="sms"&&<Card title="إعدادات SMS"><div className="max-w-md space-y-4"><InputField label="مزود الخدمة" required><select className="h-10 px-3 rounded-lg text-sm w-full outline-none" style={{border:"1px solid #CCC",backgroundColor:"#FAFAFA"}}><option>Twilio</option><option>ClickSend</option><option>Unifonic</option></select></InputField><InputField label="API Key" required placeholder="أدخل المفتاح..."/><InputField label="رقم المرسل" required placeholder="+970..."/><Btn variant="secondary" onClick={()=>toast("تم حفظ الإعدادات","success")}><Save size={16}/>حفظ الإعدادات</Btn></div></Card>}
    </div>
  );
}

function PlaceholderScreen({title}:{title:string}){return<Card title={title}><div className="flex flex-col items-center justify-center py-16 text-center"><BarChart2 size={48} className="text-[#CCC] mb-3"/><p className="text-base font-semibold text-[#555]">{title}</p><p className="text-sm text-[#999] mt-1">سيتم عرض البيانات هنا</p></div></Card>;}

// ─── APP ───────────────────────────────────────────────────────────────────────

const PAGE_TITLES:Record<string,string>={dashboard:"لوحة التحكم","open-patient":"فتح ملف مريض","new-patient":"تسجيل مريض جديد","patient-file":"ملف المريض","drawer-movements":"الجرار وحركاته","lab-session":"جلسة مختبر","test-catalog":"دليل الفحوصات والأسعار","image-catalog":"دليل الصور والأسعار","fin-summary":"الملخص المالي","fin-drawer":"الجرار — كل الأقسام","fin-revenue":"الإيرادات","fin-payroll":"الرواتب","fin-debts":"الديون","fin-statements":"الكشوفات والتقارير","inventory":"المخزون والكيتات","backup":"النسخ الاحتياطي","print-settings":"إعدادات الطباعة","general-settings":"الإعدادات العامة"};

export default function App(){
  const [collapsed,setCollapsed]=useState(false); const [alertVisible,setAlertVisible]=useState(true); const [route,setRoute]=useState<Route>({screen:"dashboard"});
  const [drawers,setDrawers]=useState(initialDrawers); const [invoices,setInvoices]=useState<Invoice[]>(initialInvoices); const [debts,setDebts]=useState<DebtRow[]>(initialDebts); const [employees,setEmployees]=useState<Employee[]>(initialEmployees);
  const [toasts,setToasts]=useState<ToastItem[]>([]); const toastRef=useRef(0);
  const toast=(msg:string,type:ToastItem["type"]="success")=>{const id=++toastRef.current;setToasts(p=>[...p,{id,msg,type}]);setTimeout(()=>setToasts(p=>p.filter(t=>t.id!==id)),3500)};
  const doWithdraw=(dept:string,amount:number,title:string,cat:string,ben?:string)=>setDrawers(d=>{const newBal=Math.max(0,d[dept].balance-amount);const tx:DrawerTx={id:Date.now(),type:"out",title,category:cat,beneficiary:ben,amount,balance:newBal,time:"الآن"};return{...d,[dept]:{balance:newBal,txs:[tx,...d[dept].txs]}};});
  const doDeposit=(dept:string,amount:number,title:string,cat:string)=>setDrawers(d=>{const newBal=d[dept].balance+amount;const tx:DrawerTx={id:Date.now(),type:"in",title,category:cat,amount,balance:newBal,time:"الآن",auto:false};return{...d,[dept]:{balance:newBal,txs:[tx,...d[dept].txs]}};});
  const totalDebt=debts.reduce((s,d)=>s+d.amount,0); const dept=route.dept||"surgery"; const sidebarW=collapsed?64:260;
  const pageTitle=(()=>{const base=PAGE_TITLES[route.screen]||route.screen;const deptInfo=DEPARTMENTS.find(d=>d.id===route.dept);return deptInfo?`${deptInfo.short} — ${base}`:base;})();
  const renderScreen=()=>{
    switch(route.screen){
      case"dashboard":         return<DashboardScreen drawers={drawers} onNavigate={setRoute}/>;
      case"open-patient":      return<OpenPatientScreen dept={dept} onNavigate={setRoute} toast={toast}/>;
      case"new-patient":       return<NewPatientScreen dept={dept} doDeposit={(d,a,t,ty)=>doDeposit(d,a,t,ty)} toast={toast}/>;
      case"patient-file":      return<PatientFileScreen/>;
      case"drawer-movements":  return<DrawerMovementsScreen dept={dept} drawer={drawers[dept]} invoices={invoices} setInvoices={setInvoices} doWithdraw={(a,t,c,b)=>doWithdraw(dept,a,t,c,b)} doDeposit={(a,t,ty)=>doDeposit(dept,a,t,ty)} toast={toast}/>;
      case"lab-session":       return<LabSessionScreen toast={toast}/>;
      case"test-catalog":      return<TestCatalogScreen toast={toast}/>;
      case"image-catalog":     return<ImageCatalogScreen toast={toast}/>;
      case"fin-summary":       return<FinancialSummaryScreen drawers={drawers}/>;
      case"fin-drawer":        return<FinAllDrawersScreen drawers={drawers}/>;
      case"fin-revenue":       return<PlaceholderScreen title="الإيرادات"/>;
      case"fin-payroll":       return<PayrollScreen employees={employees} setEmployees={setEmployees} drawers={drawers} doWithdraw={doWithdraw} toast={toast}/>;
      case"fin-debts":         return<DebtManagementScreen debts={debts} setDebts={setDebts} drawers={drawers} doDeposit={doDeposit} toast={toast}/>;
      case"fin-statements":    return<ReportsScreen toast={toast}/>;
      case"inventory":         return<InventoryScreen toast={toast}/>;
      case"backup":            return<BackupScreen toast={toast}/>;
      case"print-settings":    return<PrintSettingsScreen toast={toast}/>;
      case"general-settings":  return<GeneralSettingsScreen toast={toast}/>;
      default:                 return<DashboardScreen drawers={drawers} onNavigate={setRoute}/>;
    }
  };
  return(
    <div className="min-h-screen bg-[#F5F5F5]" style={{fontFamily:"'Tajawal',sans-serif"}} dir="rtl">
      <style>{`@keyframes slideUp{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}::-webkit-scrollbar{width:4px;height:4px}::-webkit-scrollbar-thumb{background:#CCC;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#AAA}`}</style>
      <Sidebar collapsed={collapsed} activeRoute={route} onNavigate={setRoute}/>
      <div style={{marginRight:sidebarW,transition:"margin-right 0.25s ease"}}>
        <TopBar pageTitle={pageTitle} sidebarCollapsed={collapsed} onToggle={()=>setCollapsed(!collapsed)} notifCount={3}/>
        <div style={{paddingTop:60}}>
          {alertVisible&&totalDebt>0&&<AlertBanner totalDebt={totalDebt} onClose={()=>setAlertVisible(false)}/>}
          <main className="p-6">{renderScreen()}</main>
        </div>
      </div>
      <ToastContainer toasts={toasts}/>
    </div>
  );
}
